"""Poll allowlisted GitLab pipeline run IDs for actual execution outcomes.

Run from a single AKS CronJob (not inside every web replica). GitLab trigger
credentials cannot read pipeline state; configure status_token_env separately.
Logic Apps are not guessed from the HTTP 202 and need operator verification.
"""
import logging
import os
import re
from datetime import timedelta
from urllib.parse import quote

from sqlalchemy import select

from .config import action_fingerprint, load_actions, require_https
from .db import Approval, Audit, SessionLocal, utcnow
from .dispatcher import _https_client
from .secrets import secret

LOG = logging.getLogger(__name__)
UPSTREAM_STATUS = {
    "created": "pending",
    "waiting_for_resource": "pending",
    "preparing": "pending",
    "pending": "pending",
    "scheduled": "pending",
    "running": "running",
    "success": "succeeded",
    "failed": "failed",
    "canceled": "canceled",
    "skipped": "skipped",
    "manual": "attention",
}
FINAL = {"succeeded", "failed", "canceled", "skipped"}
ACTIVE = {"pending", "running", "unknown", "attention"}


def gitlab_status(client, action: dict, run_id: str) -> str:
    if not re.fullmatch(r"[0-9]{1,18}", run_id):
        raise ValueError("Not a numeric GitLab pipeline run ID")
    token_name = action.get("status_token_env")
    if not token_name:
        if action["auth_mode"] == "trigger_api":
            raise ValueError("A GitLab trigger token cannot query pipeline status; configure status_token_env")
        token_name = action["token_env"]
    token = secret(token_name)
    base = require_https(action["base_url"]).rstrip("/")
    project = quote(str(action["project_id"]), safe="")
    url = f"{base}/api/v4/projects/{project}/pipelines/{run_id}"
    response = client.get(url, headers={"PRIVATE-TOKEN": token})
    response.raise_for_status()
    payload = response.json()
    if str(payload.get("id", "")) != run_id:
        raise ValueError("GitLab returned a different pipeline ID")
    raw = payload.get("status")
    if raw not in UPSTREAM_STATUS:
        raise ValueError("Unknown GitLab pipeline status")
    return UPSTREAM_STATUS[raw]


def sync_gitlab_runs(actions=None, limit: int = 15) -> dict:
    actions = actions if actions is not None else load_actions()
    limit = min(100, max(1, int(limit)))
    cutoff = utcnow() - timedelta(days=14)
    with SessionLocal() as db:
        runs = db.scalars(
            select(Approval)
            .where(Approval.status == "submitted",
                   Approval.execution_status.in_(ACTIVE),
                   Approval.dispatched_at >= cutoff)
            .order_by(Approval.execution_checked_at.asc().nullsfirst(), Approval.dispatched_at.desc()).limit(limit)
        ).all()
        # Capture only identifiers/attributes; no HTTP while holding a DB transaction.
        snapshots = [(r.id, r.action_key, r.action_hash, r.upstream_run_id) for r in runs]

    result = {"checked": 0, "changed": 0, "skipped": 0, "errors": 0}
    with _https_client() as client:
        for approval_id, action_key, old_hash, run_id in snapshots:
            action = actions.get(action_key)
            if (not action or action["kind"] != "gitlab" or not run_id
                    or old_hash != action_fingerprint(action)):
                result["skipped"] += 1
                continue
            if action["auth_mode"] == "trigger_api" and not action.get("status_token_env"):
                result["skipped"] += 1
                continue
            try:
                status = gitlab_status(client, action, str(run_id))
            except Exception as exc:
                result["errors"] += 1
                LOG.warning("Pipeline status check failed for approval %s (%s)", approval_id, type(exc).__name__)
                continue
            with SessionLocal.begin() as db:
                row = db.scalar(select(Approval).where(Approval.id == approval_id).with_for_update())
                if (not row or row.status != "submitted" or row.upstream_run_id != run_id
                        or row.execution_status in FINAL or row.action_hash != old_hash):
                    result["skipped"] += 1
                    continue
                result["checked"] += 1
                row.execution_checked_at = utcnow()
                if row.execution_status != status:
                    old_status = row.execution_status
                    row.execution_status = status
                    row.execution_note = f"GitLab pipeline {run_id} reports: {status}"
                    if status in FINAL:
                        row.execution_completed_at = utcnow()
                    db.add(Audit(approval_id=row.id, event="pipeline_status", actor_oid="system:gitlab-sync",
                                 actor_name="GitLab status sync", detail=f"{old_status} -> {status}"))
                    result["changed"] += 1
    return result


if __name__ == "__main__":
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
    LOG.info("Pipeline status sync complete: %s", sync_gitlab_runs(limit=int(os.getenv("GITLAB_SYNC_LIMIT", "15"))))
