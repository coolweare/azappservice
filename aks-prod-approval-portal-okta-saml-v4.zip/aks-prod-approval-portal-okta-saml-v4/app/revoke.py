"""Emergency administrative session revocation (run only through controlled access)."""
import argparse
from .security_controls import revoke_user

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--okta-user-id', required=True, help='Okta 00u... immutable user ID')
    args = parser.parse_args()
    if not args.okta_user_id.startswith('00u') or not args.okta_user_id.isalnum():
        parser.error('Invalid Okta user ID')
    print('Revoked sessions:', revoke_user(args.okta_user_id))
