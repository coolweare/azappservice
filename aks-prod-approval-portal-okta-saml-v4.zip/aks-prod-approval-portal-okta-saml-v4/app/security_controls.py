"""Database-backed atomic rate limits and revocable authoritative sessions."""
import hashlib
import secrets
import time
from datetime import timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from .db import LoginSession, RateBucket, SessionLocal, utcnow

SESSION_LIFETIME = 600       # SAML session absolutely expires 10m after login
IDLE_LIFETIME = 300          # and after 5m without access


def _utc(dt):
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def create_session(user: dict) -> str:
    sid = secrets.token_urlsafe(32)
    with SessionLocal.begin() as db:
        db.add(LoginSession(sid_hash=hashlib.sha256(sid.encode()).hexdigest(),
                            oid=user['oid'], display_name=user['name'],
                            roles=','.join(user['roles']), last_seen_at=utcnow()))
    return sid


def get_session(sid: str) -> dict | None:
    if not isinstance(sid, str) or len(sid) > 100:
        return None
    digest = hashlib.sha256(sid.encode()).hexdigest()
    with SessionLocal.begin() as db:
        row = db.scalar(select(LoginSession).where(LoginSession.sid_hash == digest).with_for_update())
        if row is None or row.revoked_at is not None:
            return None
        now = utcnow()
        if now - _utc(row.created_at) > timedelta(seconds=SESSION_LIFETIME) or now - _utc(row.last_seen_at) > timedelta(seconds=IDLE_LIFETIME):
            row.revoked_at = now
            return None
        row.last_seen_at = now
        return {'oid': row.oid, 'name': row.display_name, 'roles': row.roles.split(',')}


def revoke_session(sid: str | None) -> None:
    if not sid:
        return
    digest = hashlib.sha256(sid.encode()).hexdigest()
    with SessionLocal.begin() as db:
        for row in db.scalars(select(LoginSession).where(LoginSession.sid_hash == digest).with_for_update()):
            row.revoked_at = utcnow()


def revoke_user(okta_id: str) -> int:
    """Idempotent revocation for Okta lifecycle event receiver or administrator."""
    oid = 'okta:' + okta_id
    with SessionLocal.begin() as db:
        rows = db.scalars(select(LoginSession).where(LoginSession.oid == oid,
                                     LoginSession.revoked_at.is_(None)).with_for_update()).all()
        for row in rows:
            row.revoked_at = utcnow()
        return len(rows)


def enforce_rate_limit(key: str, max_hits: int, window_seconds: int = 60):
    """Atomic SQL upsert works across web replicas; no in-process rate limiting."""
    if not key or max_hits < 1:
        raise ValueError('Invalid rate limit')
    window = int(time.time()) // window_seconds
    digest = hashlib.sha256(key.encode()).hexdigest()
    with SessionLocal.begin() as db:
        table = RateBucket.__table__
        insert = sqlite_insert if db.bind.dialect.name == 'sqlite' else pg_insert
        stmt = insert(table).values(key_hash=digest, window=window, hits=1)
        stmt = stmt.on_conflict_do_update(
            index_elements=['key_hash', 'window'],
            set_={'hits': table.c.hits + 1})
        db.execute(stmt)
        hits = db.scalar(select(RateBucket.hits).where(RateBucket.key_hash == digest, RateBucket.window == window))
    if hits > max_hits:
        raise HTTPException(status_code=429, detail='Too many requests; try again later', headers={'Retry-After': str(window_seconds)})
