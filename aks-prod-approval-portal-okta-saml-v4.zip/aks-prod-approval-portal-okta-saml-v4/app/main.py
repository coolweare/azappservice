"""Production approval portal: Okta SAML 2.0, two-person approvals and one-shot dispatch."""
import hashlib
import json
import os
import re
import secrets
import time
from datetime import timedelta, timezone
from urllib.parse import urlparse

from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import delete, func, select, text
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .config import action_fingerprint, load_actions, require_https
from .db import Approval, Audit, SamlLogin, AttestationUse, SessionLocal, utcnow
from .dispatcher import dispatch
from .secrets import secret
from .security_controls import create_session, get_session, revoke_session, enforce_rate_limit
from .okta_events import process_event_hook
from .okta_live import check_principal_current
from .saml_auth import new_auth, principal_from_assertion, role_groups, settings


def required(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


PUBLIC_BASE_URL = require_https(required("PUBLIC_BASE_URL")).rstrip("/")
# Canonical origin, IdP pinned signing certificate and group allowlist are mandatory.
SAML_CONFIG = settings(PUBLIC_BASE_URL)
ROLE_GROUPS = role_groups()
app = FastAPI(title="Production Automation Approval Portal", docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=[urlparse(PUBLIC_BASE_URL).hostname, "127.0.0.1", "localhost"])
# Okta posts the SAML response cross-site to the ACS. SameSite=Lax drops the
# correlation cookie on that POST; SameSite=None requires HTTPS + CSRF on every
# state-changing non-ACS route (all such routes below include CSRF checks).
SESSION_COOKIE_SECRET = secret("SESSION_SECRET")
if len(SESSION_COOKIE_SECRET) < 32:
    raise RuntimeError('SESSION_SECRET must be at least 32 random characters')
app.add_middleware(SessionMiddleware, secret_key=SESSION_COOKIE_SECRET, session_cookie="approval_session",
                   same_site="none", https_only=True, max_age=600)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")
ACTIONS = load_actions()


@app.middleware("http")
async def response_headers(request: Request, call_next):
    # Native source address only; do not trust arbitrary X-Forwarded-For headers.
    # At the ingress, additionally apply per-client IP limits after REAL IP configuration.
    path = request.url.path
    try:
        if path == '/login':
            enforce_rate_limit(f'login:{request.client.host}', 15)
        elif path == '/auth/acs':
            enforce_rate_limit(f'acs:{request.client.host}', 35)
        elif path == '/api/okta/events' and request.method == 'POST':
            enforce_rate_limit(f'okta-hook:{request.client.host}', 60)
        elif request.method == 'POST' and path.startswith('/requests'):
            enforce_rate_limit(f'mutation:{request.client.host}', 80)
    except HTTPException as exc:
        return JSONResponse({'detail': exc.detail}, status_code=exc.status_code, headers=exc.headers)
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'none'; style-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


def user_or_redirect(request: Request):
    sid = request.session.get("sid")
    user = get_session(sid) if sid else None
    if not user:
        request.session.clear()
        return None
    return user


def authorize(user, *roles):
    if not set(user["roles"]).intersection(roles):
        raise HTTPException(status_code=403, detail="Insufficient Okta group-based permission")
    try:
        check_principal_current(user, set(roles))
    except (PermissionError, KeyError, ValueError):
        raise HTTPException(status_code=403, detail='Okta membership revalidation denied')
    except Exception:
        # Timeouts, 429s, outages, expired OAuth certificates MUST fail closed.
        raise HTTPException(status_code=503, detail='Okta membership verification unavailable')


def csrf_check(request: Request, supplied: str):
    expected = request.session.get("csrf")
    if not expected or not secrets.compare_digest(expected, supplied):
        raise HTTPException(status_code=403, detail="CSRF validation failed")


def log_event(db, approval, event, user, detail=""):
    db.add(Audit(approval_id=approval.id, event=event, actor_oid=user["oid"],
                 actor_name=user["name"], detail=detail[:300]))


@app.get("/healthz")
def healthz():
    return {"status": "alive"}


@app.get("/readyz")
def readyz():
    with SessionLocal() as db:
        db.execute(text("SELECT 1"))
    return {"status": "ready"}


@app.get("/saml/metadata")
def saml_metadata():
    """SP metadata URL for configuring the Okta SAML integration."""
    from fastapi.responses import Response
    auth = new_auth(PUBLIC_BASE_URL, "/saml/metadata", SAML_CONFIG)
    metadata = auth.get_settings().get_sp_metadata()
    errors = auth.get_settings().validate_metadata(metadata)
    if errors:
        raise HTTPException(status_code=500, detail="Invalid SAML SP metadata")
    return Response(metadata, media_type="application/samlmetadata+xml")


@app.get("/login")
def login(request: Request):
    """SP-initiated only. Save correlation in signed cookie AND shared database."""
    auth = new_auth(PUBLIC_BASE_URL, "/login", SAML_CONFIG)
    relay = secrets.token_urlsafe(32)
    destination = auth.login(return_to=relay)
    authn_id = auth.get_last_request_id()
    if not authn_id or len(authn_id) > 200:
        raise HTTPException(status_code=500, detail="Could not initiate SAML login")
    with SessionLocal.begin() as db:
        # Short-lived SAML request rows are not audit records; expire old rows.
        db.execute(delete(SamlLogin).where(SamlLogin.created_at < utcnow() - timedelta(days=1)))
        db.add(SamlLogin(request_id=authn_id, relay_hash=hashlib.sha256(relay.encode()).hexdigest()))
    revoke_session(request.session.get('sid'))
    request.session.clear()
    request.session["saml_request_id"] = authn_id
    request.session["saml_relay"] = relay
    request.session["saml_started_at"] = int(time.time())
    return RedirectResponse(destination, status_code=302)


@app.post("/auth/acs")
async def saml_acs(request: Request):
    """POST binding only; unsolicited/idp-initiated SAML is intentionally denied."""
    request_id = request.session.get("saml_request_id")
    relay = request.session.get("saml_relay")
    started = request.session.get("saml_started_at", 0)
    if not (isinstance(request_id, str) and isinstance(relay, str)
            and isinstance(started, int) and 0 <= time.time() - started <= 300):
        request.session.clear()
        raise HTTPException(status_code=401, detail="No active SP-initiated SAML login")
    # Limit message size before parsing. Reject missing length and oversized bodies.
    raw = await request.body()
    if len(raw) > 131072:
        raise HTTPException(status_code=413, detail="SAML POST exceeds the 128 KiB limit")
    form = await request.form()
    saml_response = form.get("SAMLResponse")
    returned_relay = form.get("RelayState")
    if (not isinstance(saml_response, str) or not saml_response
            or not isinstance(returned_relay, str)
            or not secrets.compare_digest(returned_relay, relay)):
        raise HTTPException(status_code=401, detail="Invalid SAML response or RelayState")
    auth = new_auth(PUBLIC_BASE_URL, "/auth/acs", SAML_CONFIG,
                    {"SAMLResponse": saml_response, "RelayState": returned_relay})
    with SessionLocal.begin() as db:
        # FOR UPDATE serializes an assertion's use across all AKS replicas.
        record = db.scalar(select(SamlLogin).where(SamlLogin.request_id == request_id).with_for_update())
        created_at = record.created_at if record else None
        # tz-aware in PostgreSQL; tolerate naive datetimes from local SQLite tests.
        if created_at is not None and created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        if (not record or record.consumed_at is not None
                or utcnow() - created_at > timedelta(minutes=5)
                or not secrets.compare_digest(record.relay_hash, hashlib.sha256(relay.encode()).hexdigest())):
            raise HTTPException(status_code=401, detail="SAML login expired, consumed or mismatched")
        try:
            # Toolkit validates certificate-pinned assertion XML signature,
            # issuer, audience, recipient, times, and InResponseTo.
            auth.process_response(request_id=request_id)
            if auth.get_errors() or not auth.is_authenticated():
                raise ValueError("SAML toolkit rejected the assertion")
            if auth.get_last_response_in_response_to() != request_id:
                raise ValueError("SAML response InResponseTo does not match")
            user = principal_from_assertion(auth.get_attributes(), auth.get_nameid(), ROLE_GROUPS)
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(status_code=401, detail="Okta SAML assertion validation failed") from exc
        record.consumed_at = utcnow()
    # Drop login correlation, all prior user/roles and old CSRF token.
    request.session.clear()
    request.session["sid"] = create_session(user)
    request.session["csrf"] = secrets.token_urlsafe(32)
    return RedirectResponse("/", status_code=303)


@app.post("/logout")
def logout(request: Request, csrf: str = Form(...)):
    csrf_check(request, csrf)
    revoke_session(request.session.get("sid"))
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@app.get('/api/okta/events')
def okta_hook_verify(request: Request):
    """Okta event-hook handshake only, not an authentication endpoint."""
    challenge = request.headers.get('x-okta-verification-challenge', '')
    if not 1 <= len(challenge) <= 300:
        raise HTTPException(status_code=400)
    return {'verification': challenge}


@app.post('/api/okta/events')
async def okta_hook(request: Request):
    """Revoke on user disable/suspend or membership removal.

    Require bearer secret provisioned from the web-only Key Vault mount and
    configured as Okta Event Hook's Authorization header value.
    """
    provided = request.headers.get('authorization', '')
    expected = 'Bearer ' + secret('OKTA_EVENT_HOOK_TOKEN')
    if not secrets.compare_digest(provided, expected):
        raise HTTPException(status_code=401, detail='Unauthorized event hook')
    body = await request.body()
    if len(body) > 131072:
        raise HTTPException(status_code=413)
    try:
        payload = json.loads(body)
        changed = process_event_hook(payload)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail='Invalid Okta event payload') from exc
    return {'revoked_sessions': changed}


@app.post('/api/attestations/consume')
async def consume_attestation(request: Request):
    """One-time downstream gate: check signature AND current DB approval.

    Use only over private connectivity; set GATE_API_TOKEN in protected GitLab
    gate variables and in APIM Key Vault-backed named value. Never reveal it.
    """
    supplied = request.headers.get('x-approval-gate-token', '')
    gitlab_gate = secret('GATE_GITLAB_TOKEN')
    logicapp_gate = secret('GATE_LOGICAPP_TOKEN')
    if not (secrets.compare_digest(supplied, gitlab_gate) or secrets.compare_digest(supplied, logicapp_gate)):
        raise HTTPException(status_code=401)
    raw = await request.body()
    if len(raw) > 8192:
        raise HTTPException(status_code=413)
    try:
        token = json.loads(raw)['attestation']
        if not isinstance(token, str) or len(token) > 6000:
            raise ValueError('Invalid token')
        from cryptography.hazmat.primitives.serialization import load_pem_private_key, Encoding, PublicFormat
        private = load_pem_private_key(secret('APPROVAL_SIGNING_PRIVATE_KEY').encode(), password=None)
        public_pem = private.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo).decode()
        # The validator accepts either destination audience, but requires exact
        # binding to the registered action and approval row below.
        import jwt
        hdr = jwt.get_unverified_header(token)
        if hdr.get('kid') != secret('APPROVAL_SIGNING_KID'):
            raise ValueError('Unrecognized signing key')
        claims = jwt.decode(token, public_pem, algorithms=['RS256'],
          audience=['prod-automation:gitlab', 'prod-automation:logic_app'],
          issuer='aks-prod-approval-portal',
          options={'require': ['exp','iat','nbf','jti','request_id','action_key',
                    'action_hash','package_version','change_ticket','requester',
                    'approver','approved_at','kind','environment']}, leeway=10)
        expected_gate = gitlab_gate if claims['kind'] == 'gitlab' else logicapp_gate
        if not secrets.compare_digest(supplied, expected_gate):
            raise ValueError('Gate token does not authorize that target')
        if claims['environment'] != 'prod' or claims['aud'] != 'prod-automation:' + claims['kind']:
            raise ValueError('Invalid destination')
        if claims['requester'].lower() == claims['approver'].lower():
            raise ValueError('Self approval')
    except Exception as exc:
        raise HTTPException(status_code=401, detail='Invalid approval attestation') from exc
    from sqlalchemy.exc import IntegrityError
    try:
        with SessionLocal.begin() as db:
            approval = db.scalar(select(Approval).where(Approval.id == claims['request_id']).with_for_update())
            action = ACTIONS.get(claims['action_key'])
            if (not approval or approval.status not in ('dispatching','submitted')
                or approval.action_key != claims['action_key']
                or approval.action_hash != claims['action_hash']
                or not action or action_fingerprint(action) != claims['action_hash']
                or action['kind'] != claims['kind']
                or approval.package_version != claims['package_version']
                or approval.change_ticket != claims['change_ticket']
                or (action['kind'] == 'gitlab' and (claims.get('project_id') != str(action['project_id']) or claims.get('ref') != action['ref']))
                or approval.requester_oid != claims['requester']
                or approval.decided_by_oid != claims['approver']):
                raise HTTPException(status_code=403, detail='Attestation no longer matches approved action')
            db.add(AttestationUse(jti=claims['jti'], approval_id=approval.id))
            db.flush()  # primary-key uniqueness is the replay barrier
            db.add(Audit(approval_id=approval.id, event='attestation_consumed',
               actor_oid='system:gate', actor_name='Production downstream gate',
               detail=f"Action {approval.action_key} verified by downstream gate"))
    except IntegrityError as exc:
        raise HTTPException(status_code=409, detail='Approval attestation already consumed') from exc
    return {'allowed': True, 'approval_id': claims['request_id']}


DASHBOARD_VIEWS = {"all", "pending", "approved", "running", "failed"}


def dashboard_data(db, user: dict, is_approver: bool, view: str):
    """Accurate DB totals (not computed from the limited recent-rows table)."""
    scope = [] if is_approver else [Approval.requester_oid == user["oid"]]
    aggregates = db.execute(
        select(Approval.status, Approval.execution_status, func.count(Approval.id))
        .where(*scope).group_by(Approval.status, Approval.execution_status)
    ).all()
    # Approvals expire after 24h; expired ones must not inflate 'ready' counts.
    ready_cutoff = utcnow() - timedelta(hours=24)
    ready_total = db.scalar(
        select(func.count(Approval.id)).where(
            Approval.status == "approved", Approval.decided_at >= ready_cutoff, *scope
        )
    ) or 0
    cards = {
        "pending": sum(n for status, _, n in aggregates if status == "pending"),
        "approved": ready_total,
        "running": sum(n for _, execution, n in aggregates if execution == "running"),
        "failed": sum(n for _, execution, n in aggregates if execution == "failed"),
    }
    queue_conditions = [Approval.status == "pending", *scope]
    if is_approver:
        # An Approver/Admin cannot decide their own requests.
        queue_conditions.append(func.lower(Approval.requester_oid) != user["oid"].lower())
    queue = db.scalars(
        select(Approval).where(*queue_conditions)
        .order_by(Approval.created_at.asc()).limit(15)
    ).all()
    conditions = list(scope)
    if view in {"pending", "approved"}:
        conditions.append(Approval.status == view)
        if view == "approved":
            conditions.append(Approval.decided_at >= ready_cutoff)
    elif view in {"running", "failed"}:
        conditions.append(Approval.execution_status == view)
    rows = db.scalars(
        select(Approval).where(*conditions)
        .order_by(Approval.created_at.desc()).limit(200)
    ).all()
    return cards, queue, rows


def is_expired(approval):
    """Postgres timestamps are aware, while SQLite test data may be naive UTC."""
    decided = approval.decided_at
    if decided is None:
        return True  # can't execute without a recorded decision
    if decided.tzinfo is None:
        decided = decided.replace(tzinfo=timezone.utc)
    return utcnow() - decided > timedelta(hours=24)


@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, msg: str = "", view: str = "all"):
    user = user_or_redirect(request)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if view not in DASHBOARD_VIEWS:
        raise HTTPException(status_code=400, detail="Unknown dashboard filter")
    is_approver = bool(set(user["roles"]).intersection({"Approver", "Admin"}))
    with SessionLocal() as db:
        cards, queue, approvals = dashboard_data(db, user, is_approver, view)
    messages = {
        "created": "Approval request submitted.", "approved": "Request approved; execution is now available.",
        "rejected": "Request rejected.",
        "dispatched": "Trigger accepted; upstream execution outcome is not yet confirmed.",
        "uncertain": "Dispatch outcome uncertain. Verify in GitLab/Logic Apps before any retry.",
        "verified": "Logic App execution outcome recorded with an operator audit event.",
    }
    return templates.TemplateResponse(request, "index.html", {
        "user": user, "actions": ACTIONS, "approvals": approvals,
        "queue": queue, "cards": cards, "view": view,
        "is_approver": is_approver, "notice": messages.get(msg),
        "csrf": request.session["csrf"],
        "is_expired": is_expired,
    })


@app.post("/requests")
def create_request(request: Request,
                   action_key: str = Form(...), package_version: str = Form(...),
                   change_ticket: str = Form(...), reason: str = Form(...), csrf: str = Form(...)):
    user = user_or_redirect(request)
    if not user:
        raise HTTPException(status_code=401)
    authorize(user, "Requester", "Admin")
    csrf_check(request, csrf)
    if action_key not in ACTIONS:
        raise HTTPException(status_code=400, detail="Unknown action")
    if not re.fullmatch(r"[A-Za-z0-9._+-]{1,64}", package_version):
        raise HTTPException(status_code=400, detail="Package version contains invalid characters")
    if not re.fullmatch(r"[A-Za-z0-9-]{3,40}", change_ticket):
        raise HTTPException(status_code=400, detail="Invalid change ticket")
    if not 10 <= len(reason.strip()) <= 2000:
        raise HTTPException(status_code=400, detail="Reason must contain 10–2000 characters")
    with SessionLocal.begin() as db:
        approval = Approval(action_key=action_key, action_hash=action_fingerprint(ACTIONS[action_key]),
                            package_version=package_version, change_ticket=change_ticket,
                            reason=reason.strip(), requester_oid=user["oid"], requester_name=user["name"])
        db.add(approval)
        db.flush()
        log_event(db, approval, "requested", user)
    return RedirectResponse("/?msg=created", status_code=303)


@app.post("/requests/{request_id}/decision")
def decide(request: Request, request_id: str, decision: str = Form(...), csrf: str = Form(...)):
    user = user_or_redirect(request)
    if not user:
        raise HTTPException(status_code=401)
    authorize(user, "Approver", "Admin")
    csrf_check(request, csrf)
    if decision not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="Invalid decision")
    with SessionLocal.begin() as db:
        approval = db.scalar(select(Approval).where(Approval.id == request_id).with_for_update())
        if not approval:
            raise HTTPException(status_code=404)
        if approval.status != "pending":
            raise HTTPException(status_code=409, detail="Request no longer pending")
        if approval.requester_oid.lower() == user["oid"].lower():
            raise HTTPException(status_code=403, detail="Requesters cannot approve or reject their own requests")
        action = ACTIONS.get(approval.action_key)
        if not action or approval.action_hash != action_fingerprint(action):
            raise HTTPException(status_code=409, detail="Action configuration changed; request a new approval")
        approval.status = decision
        approval.decided_by_oid = user["oid"]
        approval.decided_by_name = user["name"]
        approval.decided_at = utcnow()
        log_event(db, approval, decision, user)
    return RedirectResponse(f"/?msg={decision}", status_code=303)


@app.post("/requests/{request_id}/execute")
def execute(request: Request, request_id: str, csrf: str = Form(...)):
    user = user_or_redirect(request)
    if not user:
        raise HTTPException(status_code=401)
    csrf_check(request, csrf)
    authorize(user, "Requester", "Approver", "Admin")
    # First commit locks the request into dispatching. Do not auto-retry on error/timeout.
    with SessionLocal.begin() as db:
        approval = db.scalar(select(Approval).where(Approval.id == request_id).with_for_update())
        if not approval:
            raise HTTPException(status_code=404)
        allowed = bool(set(user["roles"]).intersection({"Approver", "Admin"})) or (
            "Requester" in user["roles"] and approval.requester_oid.lower() == user["oid"].lower())
        if not allowed:
            raise HTTPException(status_code=403, detail="Only an operator or the requester may execute an approved action")
        if approval.status != "approved":
            raise HTTPException(status_code=409, detail="Execution requires an approved request")
        if is_expired(approval):
            raise HTTPException(status_code=409, detail="Approval expired after 24 hours; submit a new request")
        action = ACTIONS.get(approval.action_key)
        if not action or approval.action_hash != action_fingerprint(action):
            raise HTTPException(status_code=409, detail="Action changed since request; submit a new approval")
        approval.status = "dispatching"
        approval.dispatched_by_oid = user["oid"]
        approval.dispatched_by_name = user["name"]
        approval.dispatched_at = utcnow()
        log_event(db, approval, "dispatch_attempt", user)
        # expire_on_commit=False retains approval values for the HTTP call.
    try:
        status, run_id, run_url = dispatch(action, approval)
    except Exception:
        # Even if HTTP timed out or returned an error, upstream MAY have accepted it.
        # Deliberately make this terminal without automatic retry.
        with SessionLocal.begin() as db:
            row = db.get(Approval, request_id)
            row.status = "dispatch_uncertain"
            row.dispatch_note = "Outcome uncertain: inspect target run history; no automatic retry"
            row.execution_status = "unknown"
            log_event(db, row, "dispatch_uncertain", user)
        return RedirectResponse("/?msg=uncertain", status_code=303)
    with SessionLocal.begin() as db:
        row = db.get(Approval, request_id)
        row.status = "submitted"
        row.upstream_http_status = status
        row.upstream_run_id = run_id
        row.upstream_run_url = run_url
        row.dispatch_note = "Request accepted by upstream; check execution status there"
        row.execution_status = "pending" if action["kind"] == "gitlab" and run_id else "unknown"
        log_event(db, row, "submitted", user, f"HTTP {status}, run id: {run_id or 'not returned'}")
    return RedirectResponse("/?msg=dispatched", status_code=303)


@app.post("/requests/{request_id}/verify")
def verify_logic_app(request: Request, request_id: str,
                     outcome: str = Form(...), evidence: str = Form(...), csrf: str = Form(...)):
    """Operator attests Logic App outcome after examining Azure run history.

    This is a MANUAL verification, not Azure telemetry. Never convert an HTTP 202
    into a success automatically. Keep final outcomes write-once.
    """
    user = user_or_redirect(request)
    if not user:
        raise HTTPException(status_code=401)
    authorize(user, "Approver", "Admin")
    csrf_check(request, csrf)
    if outcome not in ("running", "succeeded", "failed"):
        raise HTTPException(status_code=400, detail="Outcome must be running, succeeded or failed")
    evidence = evidence.strip()
    if not 20 <= len(evidence) <= 400:
        raise HTTPException(status_code=400, detail="Provide a 20–400 character Azure run-history reference and verification note")
    with SessionLocal.begin() as db:
        row = db.scalar(select(Approval).where(Approval.id == request_id).with_for_update())
        if not row:
            raise HTTPException(status_code=404)
        action = ACTIONS.get(row.action_key)
        if row.status != "submitted" or not action or action["kind"] != "logic_app":
            raise HTTPException(status_code=409, detail="Only submitted Logic Apps can be manually verified")
        if row.requester_oid.lower() == user["oid"].lower():
            raise HTTPException(status_code=403, detail="Requesters cannot attest their own execution results")
        if row.execution_status in ("succeeded", "failed", "canceled"):
            raise HTTPException(status_code=409, detail="Execution has a final outcome")
        row.execution_status = outcome
        row.execution_checked_at = utcnow()
        if outcome in ("succeeded", "failed"):
            row.execution_completed_at = utcnow()
        row.execution_note = "Manually verified in Azure run history: " + evidence
        log_event(db, row, "execution_verified", user, f"{outcome}: {evidence}")
    return RedirectResponse("/?msg=verified", status_code=303)


@app.get("/requests/{request_id}", response_class=HTMLResponse)
def detail(request: Request, request_id: str):
    user = user_or_redirect(request)
    if not user:
        return RedirectResponse("/login", status_code=303)
    with SessionLocal() as db:
        approval = db.get(Approval, request_id)
        if not approval:
            raise HTTPException(status_code=404)
        if approval.requester_oid.lower() != user["oid"].lower() and not set(user["roles"]).intersection({"Approver", "Admin"}):
            raise HTTPException(status_code=403)
        events = db.scalars(select(Audit).where(Audit.approval_id == request_id).order_by(Audit.at)).all()
    action = ACTIONS.get(approval.action_key)
    may_verify = bool(set(user["roles"]).intersection({"Approver", "Admin"})) and (
        user["oid"].lower() != approval.requester_oid.lower() and approval.status == "submitted"
        and action is not None and action["kind"] == "logic_app"
        and approval.execution_status not in ("succeeded", "failed", "canceled"))
    return templates.TemplateResponse(request, "detail.html", {
        "user": user, "approval": approval, "events": events, "may_verify": may_verify,
        "csrf": request.session["csrf"]})
