import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, create_engine, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .secrets import secret


def utcnow():
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class SamlLogin(Base):
    """Short-lived, one-time AuthnRequest IDs shared by all portal replicas."""
    __tablename__ = "saml_login_requests"
    request_id: Mapped[str] = mapped_column(String(200), primary_key=True)
    relay_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class LoginSession(Base):
    """Server-authoritative SAML session; cookie contains only an opaque handle."""
    __tablename__ = "login_sessions"
    sid_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    oid: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    roles: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AttestationUse(Base):
    """Write-once nonce: downstream verification cannot be replayed."""
    __tablename__ = "attestation_uses"
    jti: Mapped[str] = mapped_column(String(64), primary_key=True)
    approval_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    consumed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class RateBucket(Base):
    __tablename__ = "rate_buckets"
    key_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    window: Mapped[int] = mapped_column(Integer, primary_key=True)
    hits: Mapped[int] = mapped_column(Integer, nullable=False)


class AuditExportCursor(Base):
    __tablename__ = "audit_export_cursors"
    sink: Mapped[str] = mapped_column(String(60), primary_key=True)
    last_exported_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_exported_id: Mapped[str | None] = mapped_column(String(36))


class Approval(Base):
    __tablename__ = "approval_requests"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    action_key: Mapped[str] = mapped_column(String(50), nullable=False)
    action_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    package_version: Mapped[str] = mapped_column(String(64), nullable=False)
    change_ticket: Mapped[str] = mapped_column(String(40), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="pending", index=True)
    requester_oid: Mapped[str] = mapped_column(String(100), nullable=False)
    requester_name: Mapped[str] = mapped_column(String(200), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_by_oid: Mapped[str | None] = mapped_column(String(100))
    decided_by_name: Mapped[str | None] = mapped_column(String(200))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    dispatched_by_oid: Mapped[str | None] = mapped_column(String(100))
    dispatched_by_name: Mapped[str | None] = mapped_column(String(200))
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    upstream_http_status: Mapped[int | None] = mapped_column(Integer)
    upstream_run_id: Mapped[str | None] = mapped_column(String(128))
    upstream_run_url: Mapped[str | None] = mapped_column(Text)
    dispatch_note: Mapped[str | None] = mapped_column(String(300))
    # Actual upstream outcome is separate from portal approval/dispatch state.
    # NULL = not dispatched yet; unknown = accepted, but not confirmed running.
    execution_status: Mapped[str | None] = mapped_column(String(24), index=True)
    execution_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    execution_completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    execution_note: Mapped[str | None] = mapped_column(String(500))


class Audit(Base):
    __tablename__ = "approval_audit"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    approval_id: Mapped[str] = mapped_column(ForeignKey("approval_requests.id"), index=True)
    event: Mapped[str] = mapped_column(String(40), nullable=False)
    actor_oid: Mapped[str] = mapped_column(String(100), nullable=False)
    actor_name: Mapped[str] = mapped_column(String(200), nullable=False)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    detail: Mapped[str] = mapped_column(String(300), nullable=False, default="")


def get_engine():
    """Fail closed if production PostgreSQL cannot validate the server certificate."""
    import os
    from pathlib import Path
    from sqlalchemy.engine import make_url
    database_url = secret("DATABASE_URL")
    url = make_url(database_url)
    args = {}
    if url.get_backend_name() == "postgresql":
        root = os.environ.get("DB_SSL_ROOT_CERT", "/etc/ssl/certs/ca-certificates.crt")
        if not Path(root).is_file():
            raise RuntimeError("DB_SSL_ROOT_CERT path must contain trusted CA certificates")
        if url.query.get("sslmode") and url.query["sslmode"] != "verify-full":
            raise RuntimeError("Database connection cannot override TLS verify-full")
        args = {"sslmode": "verify-full", "sslrootcert": root}
    elif os.environ.get("APP_ENV", "production") != "test":
        raise RuntimeError("Production requires PostgreSQL with TLS verification")
    return create_engine(database_url, connect_args=args, pool_pre_ping=True, pool_size=5, max_overflow=5)


engine = get_engine()
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
