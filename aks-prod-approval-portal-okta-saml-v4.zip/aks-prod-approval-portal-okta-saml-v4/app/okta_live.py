"""Fail-closed, live Okta group/status revalidation for production write operations.

Uses a restricted Okta OAuth service application with private_key_jwt and scopes
okta.users.read and okta.groups.read. NEVER caches group membership/permissions.
Token itself may be cached for ~1 minute; group membership is fetched per write.
"""
import os
import re
import secrets
import time
from urllib.parse import urlparse

import httpx
import jwt

from .config import require_https
from .saml_auth import role_groups
from .secrets import secret

VALID_USER_ID = re.compile(r'^okta:(00u[A-Za-z0-9]{5,70})$')


def origin() -> str:
    base = require_https(os.environ['OKTA_ORG_URL']).rstrip('/')
    parsed = urlparse(base)
    if parsed.path or parsed.query or parsed.fragment:
        raise RuntimeError('OKTA_ORG_URL must be HTTPS origin only')
    return base


def access_token(client: httpx.Client, base: str) -> str:
    client_id = os.environ['OKTA_API_CLIENT_ID']
    now = int(time.time())
    assertion = jwt.encode({
        'iss': client_id, 'sub': client_id, 'aud': base + '/oauth2/v1/token',
        'iat': now, 'exp': now + 60, 'jti': secrets.token_urlsafe(24)
    }, secret('OKTA_API_PRIVATE_KEY'), algorithm='RS256',
    headers={'typ': 'JWT', 'kid': os.environ['OKTA_API_SIGNING_KID']})
    response = client.post(base + '/oauth2/v1/token', data={
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'scope': 'okta.users.read okta.groups.read',
        'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
        'client_assertion': assertion,
    })
    response.raise_for_status()
    data = response.json()
    if data.get('token_type', '').lower() != 'bearer' or not data.get('access_token'):
        raise PermissionError('Okta API token response invalid')
    return data['access_token']


def check_principal_current(user: dict, permitted_roles: set[str]):
    """Must succeed synchronously before request/decision/dispatch/verify.

    A missed/delayed event hook can no longer authorize a production change.
    """
    if os.environ.get('APP_ENV') == 'test':  # isolated unit tests ONLY
        return
    match = VALID_USER_ID.fullmatch(user.get('oid', ''))
    if not match:
        raise PermissionError('Okta immutable user ID missing')
    configured = role_groups()
    expected = {configured[r] for r in permitted_roles if r in user.get('roles', [])}
    if not expected:
        raise PermissionError('Session lacks a permitted role')
    base = origin()
    ca = os.environ.get('OUTBOUND_CA_BUNDLE') or True
    proxy = os.environ.get('OKTA_API_PROXY_URL')
    if proxy:
        parsed_proxy = urlparse(require_https(proxy))
        if parsed_proxy.username or parsed_proxy.password or parsed_proxy.query or parsed_proxy.fragment:
            raise RuntimeError('Okta HTTPS egress proxy URL invalid')
    with httpx.Client(timeout=httpx.Timeout(8, connect=3), follow_redirects=False,
                      trust_env=False, verify=ca, proxy=proxy) as client:
        token = access_token(client, base)
        headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/json'}
        uid = match.group(1)
        user_response = client.get(f'{base}/api/v1/users/{uid}', headers=headers)
        user_response.raise_for_status()
        if user_response.json().get('status') != 'ACTIVE':
            raise PermissionError('Okta user is no longer ACTIVE')
        group_response = client.get(f'{base}/api/v1/users/{uid}/groups',
                                    params={'limit': '200'}, headers=headers)
        group_response.raise_for_status()
        groups = group_response.json()
        if not isinstance(groups, list):
            raise PermissionError('Malformed Okta groups response')
        actual = {g.get('profile', {}).get('name') for g in groups if isinstance(g, dict)
                  and isinstance(g.get('profile'), dict)}
        if not expected.intersection(actual):
            raise PermissionError('Required Okta group membership was revoked')
