"""Idempotent audit exporter to Azure Blob with a LOCKED immutability policy.

Storage WORM retention and immutability policy lock MUST be provisioned in Azure
separately. No application code can make an ordinary storage account immutable.
"""
import hashlib
import json
import logging
import os

from azure.core.exceptions import ResourceExistsError
from azure.identity import WorkloadIdentityCredential, AzureAuthorityHosts
from azure.storage.blob import BlobServiceClient
from sqlalchemy import select

from .db import Audit, AuditExportCursor, SessionLocal

LOG = logging.getLogger(__name__)


def export_once(limit=200):
    account = os.environ['AUDIT_STORAGE_ACCOUNT']
    container = os.environ['AUDIT_IMMUTABLE_CONTAINER']
    prefix = os.environ.get('AUDIT_PREFIX', 'prod-automation/audit').strip('/')
    cloud = os.getenv('AZURE_CLOUD', 'AzurePublicCloud')
    if cloud == 'AzureUSGovernment':
        suffix = 'blob.core.usgovcloudapi.net'
        credential = WorkloadIdentityCredential(authority=AzureAuthorityHosts.AZURE_GOVERNMENT)
    elif cloud == 'AzurePublicCloud':
        suffix = 'blob.core.windows.net'
        credential = WorkloadIdentityCredential()
    else:
        raise ValueError('AZURE_CLOUD must be AzurePublicCloud or AzureUSGovernment')
    try:
        service = BlobServiceClient(account_url=f'https://{account}.{suffix}', credential=credential)
        output = service.get_container_client(container)
        with SessionLocal.begin() as db:
            cursor = db.get(AuditExportCursor, 'azure-immutable-blob')
            if not cursor:
                cursor = AuditExportCursor(sink='azure-immutable-blob')
                db.add(cursor)
                db.flush()
            stmt = select(Audit)
            if cursor.last_exported_at is not None:
                from sqlalchemy import and_, or_
                stmt = stmt.where(or_(Audit.at > cursor.last_exported_at,
                    and_(Audit.at == cursor.last_exported_at, Audit.id > cursor.last_exported_id)))
            rows = db.scalars(stmt.order_by(Audit.at, Audit.id).limit(limit)).all()
            sent = 0
            for a in rows:
                body = json.dumps({'id': a.id, 'approval_id': a.approval_id,
                                   'event': a.event, 'actor_oid': a.actor_oid,
                                   'actor_name': a.actor_name, 'at': a.at.isoformat(),
                                   'detail': a.detail}, sort_keys=True, separators=(',', ':')).encode()
                digest = hashlib.sha256(body).hexdigest()
                blob = output.get_blob_client(f'{prefix}/{a.id}.json')
                try:
                    blob.upload_blob(body, overwrite=False, metadata={'sha256': digest},
                                     if_none_match='*')
                    sent += 1
                except ResourceExistsError:
                    pass
                cursor.last_exported_at = a.at
                cursor.last_exported_id = a.id
            LOG.info('Shipped %s of %s audit records', sent, len(rows))
            return sent
    finally:
        credential.close()


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    export_once(int(os.environ.get('AUDIT_EXPORT_LIMIT', '200')))
