"""RS256 approval evidence, bound to exact request/action, for independent downstream gates.

Signer private key lives ONLY in the web pod's Key Vault. The GitLab gate and
Azure API Management get the public key, never a token or password.
"""
import time
import uuid

import jwt
from jwt import InvalidTokenError

from .config import action_fingerprint
from .secrets import secret

ISSUER = 'aks-prod-approval-portal'
TTL_SECONDS = 180


def build_attestation(approval, action: dict) -> str:
    if approval.status != 'dispatching' or not approval.decided_by_oid or not approval.requester_oid:
        raise ValueError('An accepted two-person approval is required')
    if approval.decided_by_oid.lower() == approval.requester_oid.lower():
        raise ValueError('Requesters cannot approve their own requests')
    if approval.action_hash != action_fingerprint(action):
        raise ValueError('Action definition changed after approval')
    kind = action['kind']
    issued = int(time.time())
    claims = {
        'iss': ISSUER, 'aud': f'prod-automation:{kind}',
        'iat': issued, 'nbf': issued - 5, 'exp': issued + TTL_SECONDS,
        'jti': str(uuid.uuid4()),
        'request_id': approval.id, 'action_key': approval.action_key,
        'action_hash': approval.action_hash, 'package_version': approval.package_version,
        'change_ticket': approval.change_ticket, 'requester': approval.requester_oid,
        'approver': approval.decided_by_oid, 'approved_at': int(approval.decided_at.timestamp()),
        'kind': kind, 'environment': 'prod',
    }
    if kind == 'gitlab':
        claims['project_id'] = str(action['project_id'])
        claims['ref'] = action['ref']
    key = secret('APPROVAL_SIGNING_PRIVATE_KEY')
    kid = secret('APPROVAL_SIGNING_KID')
    return jwt.encode(claims, key, algorithm='RS256', headers={'kid': kid, 'typ': 'JWT'})


def verify_attestation(token: str, public_pem: str, audience: str, *, now: int | None = None) -> dict:
    headers = jwt.get_unverified_header(token)
    if headers.get('alg') != 'RS256' or headers.get('typ') not in ('JWT', None):
        raise InvalidTokenError('Invalid approval token algorithm/type')
    opts = {'require': ['iss', 'aud', 'exp', 'iat', 'nbf', 'jti', 'request_id',
                        'action_key', 'action_hash', 'package_version', 'change_ticket',
                        'requester', 'approver', 'approved_at', 'kind', 'environment']}
    claims = jwt.decode(token, public_pem, algorithms=['RS256'], audience=audience,
                        issuer=ISSUER, options=opts, leeway=10)
    if claims['requester'].lower() == claims['approver'].lower():
        raise InvalidTokenError('Self-approval is forbidden')
    if claims['environment'] != 'prod' or claims['kind'] not in ('gitlab', 'logic_app'):
        raise InvalidTokenError('Invalid approval target')
    return claims
