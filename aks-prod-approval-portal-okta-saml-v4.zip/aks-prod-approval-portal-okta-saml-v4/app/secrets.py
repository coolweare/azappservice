"""Read secrets from Azure Key Vault CSI file mounts (preferred) or environment."""
import os
from pathlib import Path


def secret(name: str) -> str:
    folder = os.getenv("SECRETS_DIR", "/mnt/secrets")
    path = Path(folder) / name
    if path.is_file():
        value = path.read_text(encoding="utf-8").strip()
    else:
        value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required secret: {name}")
    return value
