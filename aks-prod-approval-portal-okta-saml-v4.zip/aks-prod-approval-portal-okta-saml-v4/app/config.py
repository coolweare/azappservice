"""Immutable, admin-supplied allowlist of actions; never accept arbitrary URLs from users."""
import hashlib
import json
import os
import re
from pathlib import Path
from urllib.parse import urlparse

import yaml


VALID_KEY = re.compile(r"^[a-z][a-z0-9_-]{1,49}$")
VALID_VAR = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
ALLOWED_PLACEHOLDERS = {"{package_version}", "{change_ticket}", "{request_id}"}


def require_https(url: str) -> str:
    p = urlparse(url)
    if p.scheme != "https" or not p.hostname or p.username or p.password or p.fragment:
        raise ValueError("URL must be HTTPS with a hostname and without userinfo/fragment")
    return url


def load_actions(path: str | None = None) -> dict:
    raw = yaml.safe_load(Path(path or os.environ.get("ACTIONS_PATH", "/app/actions.yaml")).read_text())
    actions = raw.get("actions") if isinstance(raw, dict) else None
    if not isinstance(actions, dict) or not actions:
        raise ValueError("actions.yaml must contain an actions mapping")
    for key, a in actions.items():
        if not isinstance(key, str) or not VALID_KEY.fullmatch(key):
            raise ValueError(f"Invalid action key: {key}")
        if not isinstance(a, dict) or a.get("kind") not in ("gitlab", "logic_app"):
            raise ValueError(f"Invalid action type for {key}")
        if a.get('require_attestation') is not True:
            raise ValueError(f'Action {key}: require_attestation: true is mandatory')
        if not isinstance(a.get("label"), str) or not a["label"].strip():
            raise ValueError(f"Action {key}: label required")
        if a["kind"] == "gitlab":
            require_https(a["base_url"])
            parsed = urlparse(a["base_url"])
            if parsed.query or parsed.path.rstrip("/") not in ("",):
                raise ValueError("GitLab base_url must be just https://hostname[:port]")
            if not re.fullmatch(r"[0-9]+", str(a["project_id"])):
                raise ValueError("Use numeric GitLab project_id")
            if not re.fullmatch(r"[A-Za-z0-9_.\-/]{1,100}", a["ref"]):
                raise ValueError("Unsafe GitLab ref")
            if a.get("auth_mode") not in ("pipeline_api", "trigger_api"):
                raise ValueError("auth_mode must be pipeline_api or trigger_api")
            if a["auth_mode"] == "trigger_api" and a.get("inputs"):
                raise ValueError("inputs require pipeline_api")
            token_env = a.get("token_env", "")
            if not VALID_VAR.fullmatch(token_env):
                raise ValueError("token_env must be environment variable name")
            # A trigger token cannot read the GitLab Pipelines API. A separate
            # read credential is required to monitor trigger_api executions.
            status_token = a.get("status_token_env", token_env if a["auth_mode"] == "pipeline_api" else "")
            if status_token and not VALID_VAR.fullmatch(status_token):
                raise ValueError("status_token_env must be an environment variable name")
            if not isinstance(a.get("variables", {}), dict):
                raise ValueError("GitLab variables must be a mapping")
            if not isinstance(a.get("inputs", {}), dict):
                raise ValueError("GitLab inputs must be a mapping")
            for name in a.get("variables", {}):
                if name == 'APPROVAL_ATTESTATION':
                    raise ValueError('APPROVAL_ATTESTATION is reserved for the portal signer')
                if not VALID_VAR.fullmatch(name):
                    raise ValueError("Unsafe GitLab variable key")
        else:
            if not isinstance(a.get('gateway_host'), str) or not re.fullmatch(r'[A-Za-z0-9.-]{4,253}', a['gateway_host']):
                raise ValueError('Logic App requires a fixed private APIM gateway_host')
            if not VALID_VAR.fullmatch(a.get("callback_url_env", "")):
                raise ValueError("callback_url_env must be environment variable name")
            if 'APPROVAL_ATTESTATION' in a.get('payload', {}):
                raise ValueError('Reserved attestation payload name')
            if not isinstance(a.get("payload"), dict):
                raise ValueError("Logic App payload must be mapping")
        # Explicit placeholder substitution; disable arbitrary formatting/expression evaluation.
        def validate_strings(node):
            if isinstance(node, dict):
                for v in node.values():
                    validate_strings(v)
            elif isinstance(node, list):
                for v in node:
                    validate_strings(v)
            elif isinstance(node, str):
                matches = re.findall(r"\{[^{}]+\}", node)
                if not set(matches).issubset(ALLOWED_PLACEHOLDERS):
                    raise ValueError(f"Action {key}: unknown placeholder")
        validate_strings(a)
        # Hashing and HTTP serialization must succeed at startup, not at dispatch time.
        json.dumps(a, sort_keys=True)
    return actions


def action_fingerprint(action: dict) -> str:
    # Any change in the action definition invalidates existing approval requests.
    return hashlib.sha256(json.dumps(action, sort_keys=True).encode()).hexdigest()


def substitute(obj, data: dict):
    """Safe recursive substitution of *known* placeholders only."""
    if isinstance(obj, str):
        for key in ("package_version", "change_ticket", "request_id"):
            obj = obj.replace("{" + key + "}", data[key])
        return obj
    if isinstance(obj, dict):
        return {k: substitute(v, data) for k, v in obj.items()}
    if isinstance(obj, list):
        return [substitute(v, data) for v in obj]
    return obj
