from .db import Base, engine


def migrate():
    # Bootstrap only; use a reviewed Alembic migration on subsequent schema changes.
    Base.metadata.create_all(engine)
    print("Database schema created/verified")


if __name__ == "__main__":
    migrate()
