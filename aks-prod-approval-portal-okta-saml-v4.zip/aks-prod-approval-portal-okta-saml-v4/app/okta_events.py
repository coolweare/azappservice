"""Authenticated Okta Event Hook lifecycle revocation.

Okta events are asynchronous; the app also enforces a 10-minute maximum
session lifetime. There is no claim of instantaneous Okta deprovisioning.
"""
import re
from .security_controls import revoke_user

OKTA_ID_RE = re.compile(r'^00u[A-Za-z0-9]{10,40}$')
REVOCATION_TYPES = {
    'user.lifecycle.deactivate', 'user.lifecycle.suspend',
    'application.user_membership.remove', 'group.user_membership.remove',
}


def process_event_hook(data: dict, *, allowed_groups: set[str] | None = None) -> int:
    # For a group removal, conservatively revoke the user's entire portal session,
    # regardless of the specific group, so role grants can't remain cached.
    events = data.get('data', {}).get('events', []) if isinstance(data, dict) else []
    if not isinstance(events, list) or len(events) > 50:
        raise ValueError('Invalid event batch')
    total = 0
    for event in events:
        if not isinstance(event, dict) or event.get('eventType') not in REVOCATION_TYPES:
            continue
        targets = event.get('target', [])
        if not isinstance(targets, list):
            continue
        # Okta target includes {type:'User', id:'00u...'} for affected users.
        ids = {t['id'] for t in targets if isinstance(t, dict) and t.get('type') == 'User'
               and isinstance(t.get('id'), str) and OKTA_ID_RE.fullmatch(t['id'])}
        for oid in ids:
            total += revoke_user(oid)
    return total
