"""Strict, SP-initiated Okta SAML 2.0 integration for the approval portal.

The XML signature, Audience, Issuer, Recipient/Destination, Conditions and
InResponseTo checks are delegated to python3-saml in strict mode; the portal
additionally binds an AuthnRequest to a browser and consumes it atomically in DB.
"""
import base64
import binascii
import os
import re
from urllib.parse import urlparse

from .config import require_https
from .secrets import secret

VALID_OKTA_ID = re.compile(r"^00u[A-Za-z0-9]{5,70}$")


def required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required Okta SAML setting: {name}")
    return value


def x509_body(value: str) -> str:
    """Accept PEM or naked Base64 X.509 DER certificate; never cert fingerprints."""
    value = value.strip()
    match = re.fullmatch(
        r"-----BEGIN CERTIFICATE-----\s*([A-Za-z0-9+/=\s]+)\s*-----END CERTIFICATE-----",
        value,
    )
    body = match.group(1) if match else value
    body = "".join(body.split())
    try:
        decoded = base64.b64decode(body, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise RuntimeError("OKTA_IDP_X509_CERT must be a PEM/base64 X.509 certificate") from exc
    if not decoded.startswith(b"\x30") or len(decoded) < 400:
        raise RuntimeError("OKTA_IDP_X509_CERT does not look like an X.509 DER certificate")
    return body


def settings(public_base_url: str) -> dict:
    base = require_https(public_base_url).rstrip("/")
    sso_url = require_https(required("OKTA_SAML_SSO_URL"))
    sso = urlparse(sso_url)
    if not sso.path.startswith("/") or sso.path == "/" or sso.query or sso.fragment:
        raise RuntimeError("OKTA_SAML_SSO_URL must be an HTTPS IdP SSO endpoint without query string")
    idp_issuer = required("OKTA_SAML_IDP_ENTITY_ID")
    if len(idp_issuer) > 500:
        raise RuntimeError("Invalid OKTA_SAML_IDP_ENTITY_ID")
    cert = x509_body(secret("OKTA_IDP_X509_CERT"))
    return {
        "strict": True,
        "debug": False,
        "sp": {
            "entityId": f"{base}/saml/metadata",
            "assertionConsumerService": {
                "url": f"{base}/auth/acs",
                "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
            },
            "NameIDFormat": "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified",
        },
        "idp": {
            "entityId": idp_issuer,
            "singleSignOnService": {
                "url": sso_url,
                "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
            },
            "x509cert": cert,
        },
        "security": {
            "authnRequestsSigned": False,  # Okta custom SAML app must allow unsigned requests.
            "wantAssertionsSigned": True,   # Require Okta to sign assertion, not merely response.
            "wantMessagesSigned": False,
            "wantNameId": True,
            "rejectUnsolicitedResponsesWithInResponseTo": True,
            "rejectDeprecatedAlgorithm": True,
            # Let Okta sign-on policy enforce MFA; don't force PasswordProtectedTransport
            # AuthnContext which may conflict with modern MFA/authenticator types.
            "requestedAuthnContext": False,
            "signatureAlgorithm": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256",
            "digestAlgorithm": "http://www.w3.org/2001/04/xmlenc#sha256",
        },
    }


def request_data(public_base_url: str, path: str, post_data: dict | None = None) -> dict:
    """Use configured canonical external scheme/host, never untrusted X-Forwarded-Host."""
    parsed = urlparse(public_base_url)
    return {
        "https": "on", "http_host": parsed.netloc, "server_port": str(parsed.port or 443),
        "script_name": path, "get_data": {}, "post_data": post_data or {},
    }


def new_auth(public_base_url: str, path: str, config: dict, post_data: dict | None = None):
    # Imported only when needed; business-rule tests can run independently.
    from onelogin.saml2.auth import OneLogin_Saml2_Auth

    return OneLogin_Saml2_Auth(request_data(public_base_url, path, post_data), old_settings=config)


def role_groups() -> dict[str, str]:
    groups = {
        "Requester": required("OKTA_GROUP_REQUESTER"),
        "Approver": required("OKTA_GROUP_APPROVER"),
        "Admin": required("OKTA_GROUP_ADMIN"),
    }
    if len(set(groups.values())) != len(groups):
        raise RuntimeError("Each Okta approval role must map to a different Okta group")
    return groups


def principal_from_assertion(attributes: dict, nameid: str | None, group_mapping: dict) -> dict:
    """Authorize with exact, signed group attribute values. Fail closed."""
    user_ids = attributes.get("oktaUserId", [])
    if not isinstance(user_ids, list) or len(user_ids) != 1 or not isinstance(user_ids[0], str):
        raise ValueError("Signed assertion must include one oktaUserId attribute")
    user_id = user_ids[0]
    if not VALID_OKTA_ID.fullmatch(user_id):
        raise ValueError("Invalid immutable Okta user identifier")
    groups = attributes.get("groups", [])
    if not isinstance(groups, list) or not all(isinstance(g, str) for g in groups):
        raise ValueError("Invalid groups attribute")
    roles = sorted(role for role, group in group_mapping.items() if group in groups)
    if not roles:
        raise PermissionError("User is not a member of an authorized production approval group")
    display = attributes.get("displayName", [])
    preferred = display[0] if isinstance(display, list) and len(display) == 1 and isinstance(display[0], str) else nameid
    return {"oid": "okta:" + user_id, "name": str(preferred or "Okta user")[:200], "roles": roles}
