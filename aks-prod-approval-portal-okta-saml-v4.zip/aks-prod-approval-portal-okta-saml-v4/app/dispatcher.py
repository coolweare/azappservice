"""Calls registered targets once; HTTP errors/timeouts are conservatively 'uncertain'."""
import os
from urllib.parse import quote, urlparse

import httpx

from .config import require_https, substitute
from .approval_attestation import build_attestation
from .secrets import secret


class DispatchError(Exception):
    pass


def _https_client():
    ca_bundle = os.getenv("OUTBOUND_CA_BUNDLE") or True
    return httpx.Client(timeout=httpx.Timeout(15.0, connect=5.0), verify=ca_bundle,
                        follow_redirects=False, trust_env=False)


def dispatch(action: dict, approval) -> tuple[int, str | None, str | None]:
    if action.get('require_attestation') is not True:
        raise DispatchError('Production action must require cryptographic approval attestation')
    evidence = build_attestation(approval, action)
    values = {"package_version": approval.package_version,
              "change_ticket": approval.change_ticket, "request_id": approval.id}
    with _https_client() as client:
        if action["kind"] == "gitlab":
            token = secret(action["token_env"])
            base = require_https(action["base_url"]).rstrip("/")
            pid = quote(str(action["project_id"]), safe="")
            ref = action["ref"]
            variables = substitute(action.get("variables", {}), values)
            # This is a signed, short-lived assertion. A downstream gate MUST
            # validate it before accessing production credentials/resources.
            variables['APPROVAL_ATTESTATION'] = evidence
            if action["auth_mode"] == "pipeline_api":
                endpoint = f"{base}/api/v4/projects/{pid}/pipeline"
                body = {"ref": ref, "variables": [{"key": k, "value": str(v)} for k, v in variables.items()]}
                if action.get("inputs"):
                    body["inputs"] = substitute(action["inputs"], values)
                response = client.post(endpoint, headers={"PRIVATE-TOKEN": token}, json=body)
            else:
                endpoint = f"{base}/api/v4/projects/{pid}/trigger/pipeline"
                form = {"token": token, "ref": ref}
                form.update({f"variables[{k}]": str(v) for k, v in variables.items()})
                response = client.post(endpoint, data=form)
            if not 200 <= response.status_code < 300:
                raise DispatchError(f"GitLab returned HTTP {response.status_code}; check GitLab before retrying")
            output = response.json()
            run_id = str(output["id"]) if "id" in output else None
            url = output.get("web_url")
            # Don't use untrusted URLs from HTTP response as clickable links unless same GitLab hostname.
            if url and (urlparse(url).scheme != "https" or urlparse(url).netloc != urlparse(base).netloc):
                url = None
            return response.status_code, run_id, url

        callback = require_https(secret(action["callback_url_env"]))
        url_parts = urlparse(callback)
        if (url_parts.hostname != action['gateway_host'] or url_parts.query
                or url_parts.username or url_parts.password):
            raise DispatchError('Logic App callback must be the configured APIM gateway without SAS query')
        payload = substitute(action["payload"], values)
        # Point callback at an APIM gateway enforcing validate-jwt and network
        # isolation. Do not expose the underlying Logic App SAS trigger directly.
        response = client.post(callback, json=payload,
                               headers={"Content-Type": "application/json", "Authorization": "Bearer " + evidence})
        if not 200 <= response.status_code < 300:
            raise DispatchError(f"Logic App returned HTTP {response.status_code}; check run history before retrying")
        # Never store SAS URL or access key from callback URL; response may be 202 Accepted.
        run_id = response.headers.get("x-ms-workflow-run-id")
        return response.status_code, run_id[:128] if run_id else None, None
