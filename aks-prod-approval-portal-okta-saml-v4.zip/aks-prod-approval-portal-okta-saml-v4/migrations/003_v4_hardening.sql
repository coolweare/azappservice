-- Run with privileged migration identity before deployment. Safe for existing v3 data.
BEGIN;
CREATE TABLE IF NOT EXISTS login_sessions (
    sid_hash VARCHAR(64) PRIMARY KEY, oid VARCHAR(100) NOT NULL,
    display_name VARCHAR(200) NOT NULL, roles VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at TIMESTAMPTZ NOT NULL, revoked_at TIMESTAMPTZ NULL);
CREATE INDEX IF NOT EXISTS ix_login_sessions_oid ON login_sessions(oid);
CREATE TABLE IF NOT EXISTS attestation_uses (
    jti VARCHAR(64) PRIMARY KEY,
    approval_id VARCHAR(36) NOT NULL,
    consumed_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX IF NOT EXISTS ix_attestation_uses_approval_id ON attestation_uses(approval_id);
CREATE TABLE IF NOT EXISTS rate_buckets (
    key_hash VARCHAR(64) NOT NULL, window INTEGER NOT NULL, hits INTEGER NOT NULL,
    PRIMARY KEY(key_hash, window));
CREATE TABLE IF NOT EXISTS audit_export_cursors (
    sink VARCHAR(60) PRIMARY KEY, last_exported_at TIMESTAMPTZ,
    last_exported_id VARCHAR(36));
-- Prevent routine users (including web and sync) from editing the security audit.
CREATE OR REPLACE FUNCTION prevent_approval_audit_rewrite()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Approval audit is append-only';
END; $$;
DROP TRIGGER IF EXISTS approval_audit_append_only ON approval_audit;
CREATE TRIGGER approval_audit_append_only BEFORE UPDATE OR DELETE ON approval_audit
FOR EACH ROW EXECUTE FUNCTION prevent_approval_audit_rewrite();
COMMIT;
