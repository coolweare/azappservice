-- Additive migration for Okta SAML v3; preserves all existing approval/audit rows.
-- Execute with a controlled migration account BEFORE rolling out the new image.
BEGIN;
ALTER TABLE approval_requests
    ADD COLUMN IF NOT EXISTS execution_status VARCHAR(24),
    ADD COLUMN IF NOT EXISTS execution_checked_at TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS execution_completed_at TIMESTAMP WITH TIME ZONE,
    ADD COLUMN IF NOT EXISTS execution_note VARCHAR(500);
CREATE INDEX IF NOT EXISTS ix_approval_requests_execution_status ON approval_requests (execution_status);
COMMIT;
