-- Additive migration for EXISTING PostgreSQL approval portal installations.
-- Does not modify approval_requests or approval_audit or existing approvals.
-- Run using a migration/admin DB identity BEFORE rolling out v2.
BEGIN;
CREATE TABLE IF NOT EXISTS saml_login_requests (
    request_id VARCHAR(200) PRIMARY KEY,
    relay_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    consumed_at TIMESTAMP WITH TIME ZONE NULL
);
CREATE INDEX IF NOT EXISTS ix_saml_login_requests_created_at
    ON saml_login_requests (created_at);
COMMIT;
