# v4 upgrade/runbook (from Okta SAML v3)

## Stop/go controls

- Freeze approvals and perform tested PostgreSQL point-in-time-restorable backup.
- Enumerate every active v3 approved/dispatching request. Finish or revoke them before upgrade. v4 rejects old approvals because the cryptographically gated action hash changes.
- Prepare the Okta SAML certificate, new Okta OAuth service app with `okta.users.read` and `okta.groups.read`, OAuth private key, group claim mapping, live API HTTPS egress (prefer enterprise proxy), and optional hook.
- Generate a strong RSA signer and separate randomly generated GitLab and Logic App gate tokens. Store in web-only Key Vault, register public PEM with downstream verifiers. Rotate old/compromised credentials as part of release.
- Set up isolated DB roles, four Workload Identities/Key Vault access scopes and immutable audit Blob account; **lock retention after review**. Audit exporter must be granted write but no delete on a WORM container.
- Deploy and exercise mandatory GitLab protected gate and APIM verify+one-time-consume gateway **before any real production execution**. Restrict the Logic App callback so it cannot bypass APIM; require private ingress on AKS web.
- Obtain signed image digest and enforce admission policy. Replace example CIDRs for SQL, GitLab, APIM, Okta egress proxy, blob and identity.

## Sequencing

1. Build in isolated CI. Resolve transitive package dependencies, scan SAST/dependency/secrets/image/SBOM, sign and verify image. Fail build on HIGH/CRITICAL.
2. Preconfigure 4 distinct Key Vault identities, connections, sessions, signing key, Okta API, DNS/firewalls, private ingress.
3. Apply `migrations/003_v4_hardening.sql` with the migration role. Apply role grants in `scripts/migrations/004_app_roles.sql` after admin precreates app roles. Retain existing approval/audit data.
4. Validate database `sslmode=verify-full` using your trusted cert file. Ensure all server-side sessions are new and can be revoked; old browser cookies no longer authorize.
5. Roll out signed v4 image, GitLab status CronJob and audit exporter; verify their pods use separate service accounts, each CSI mount contains only their role's secrets.
6. Confirm in a pre-production environment: Okta SAML signatures/group mapping; live Okta API revocation; signed downstream gate (`jti` single use); all negative cases; APIM payload reconstructed from signed claims; GitLab protected runner; audit WORM; network-policy deny/allow and Azure Gov authority where applicable.
7. Start production by unfreezing approvals after the change is approved and all prerequisites prove healthy.

## Security rollback

- Never bypass signed gate to roll back. Create a *new* approved change with a previous known-good image/release version and new signed evidence.
- If the web app fails after 003, freeze dispatch and stop the web Deployment; do **not** automatically drop v4 tables or triggers because they hold security evidence.
- If operational rollback to v3 is unavoidable, involve change/security owner: v3 has known security gaps. Revert networking and app images only through approved recovery plan, protect DB/audit backups, keep old approvals disabled, and revoke exposed tokens. Prefer fixing-forward.
- Lost APIM/Okta connectivity must fail closed, not trigger retry or bypass. Uncertain dispatches require manual upstream verification.

## Evidence required for release signoff

- Resolved dependency graph and `pip-audit` output; tested signed container digest and image CVE scan.
- Database migration output, `sslmode=verify-full` evidence, separated DB GRANTs, four managed identity access reports.
- Live Okta/SSO test, removal of approver group between session and POST (403), and suspended user denied.
- GitLab API attempt without JWT denied, wrong branch/project/ref/version denied, two-person approval positive, replay denied.
- APIM bad signature/SAS direct bypass denied, changed JSON payload unable to change signed version, monitored Logic App outcome.
- Blob immutability **Locked** screenshot/export, exporter backlog alarm, tested audit record and attempted deletion denied.
- Kubernetes ingress/egress network policy enforcement verified by network probes and logs. Restore test and rollback signoff.
