# AKS Production Automation Approval Portal — Okta SAML + Operations Dashboard (v3)

FastAPI dashboard deployed to Azure Kubernetes Service (AKS). Employees authenticate with **Okta SAML 2.0**, request production changes, and designated Okta group members approve or reject changes. After a separate **Trigger automation** action, the portal invokes a fixed, Git-reviewed **GitLab pipeline** or **Azure Logic App**. PostgreSQL holds approval requests, an audit trail, one-use SAML login correlation records, and **upstream execution state** tracked separately from approval status.

**Okta replaces Microsoft Entra as the portal's user sign-in system.** Azure Workload Identity is still used **only for the AKS workload to access Azure Key Vault via the CSI driver**. It does not authenticate employees or determine approval roles. Compatible with AKS in Azure Commercial or Government when the Key Vault CSI configuration uses the correct tenant/cloud.

> **Production reference implementation, not production-certified.** No live Okta tenant, actual signed SAML assertion, AKS image build or GitLab/Logic App endpoint has been available for integration testing here. Review hardening, run the tests and verify a real Okta handshake before production rollout.

## Approval workflow

```text
Browser -> internal AKS ingress -> GET /login -> Okta SAML SSO
                                        |
     Browser POST /auth/acs <- signed Okta SAML assertion
                     | validate signature, InResponseTo, RelayState, Okta immutable ID and groups
                     v
    Okta Requester -> PENDING request -> different Okta Approver/Admin
                                               | approve or reject
                                               v
                    APPROVED (24h max, not yet executed)
                                               |
                              Requester or Approver/Admin triggers
                                               |
                      GitLab pipeline API   OR   Azure Logic Apps Request endpoint
                                               |
                            POST accepted = SUBMITTED (not confirmed succeeded)
                                         |
                  GitLab: status CronJob (every 2m, API read)
                  Logic App: authorized operator verifies run history
                                         |
                RUNNING / SUCCEEDED / FAILED (independent execution state)
```

**Segregation of duties:** A person cannot approve/reject their own request even if they belong to multiple Okta groups. All production actions are defined by administrators in `actions.yaml`, never as user-supplied URLs, script paths, project IDs or pipeline refs.

## Files

- `app/saml_auth.py` — pinned Okta IdP signing certificate, strict SAML 2.0 settings, canonical SP URL, exact group-to-role mapping, immutable Okta user ID.
- `app/main.py` — SP-initiated login (`GET /login`), assertion consumer (`POST /auth/acs`), SP metadata (`GET /saml/metadata`), CSRF, approvals and execution.
- `app/db.py` — approvals/audit and `saml_login_requests`, plus execution status/verification timestamps on the approval record.
- `app/status_sync.py` — read-only GitLab pipeline run status reconciliation; updates are audited, with no automatic re-dispatch.
- `deploy/09-gitlab-status-cronjob.yaml` — single scheduled status poller (every two minutes; Kubernetes `concurrencyPolicy: Forbid`).
- `migrations/001_okta_saml_login_requests.sql` — additive SAML table migration for old Entra installations.
- `migrations/002_execution_tracking.sql` — additive execution status fields for both v1 and v2 upgrades (no approval/audit rows are rewritten).
- `deploy/` — AKS manifests and Azure Key Vault CSI provider. `deploy/07-migrate-job.yaml` only bootstraps brand-new databases.
- `actions.yaml` — approved GitLab and Logic App destinations; `examples/` — sample payload and GitLab inputs.
- `UPGRADE_v3.md` — condensed upgrade steps for existing Okta v2 AKS installations.
- `tests/test_saml.py` — SAML claim/role and config tests; `tests/test_dashboard_enhancement.py` covers queues, summary counters, GitLab status reconciliation, and Logic App verified results.
- `docs/dashboard-preview.png` — screenshot rendered from the current HTML/CSS with simulated, fictional values. It is not a live AKS screenshot; `docs/render_preview.py` regenerates it if Playwright and Chromium are installed.

## 1. Create the Okta SAML application

In **Okta Admin Console > Applications > Applications > Create App Integration > SAML 2.0**:

| Okta SAML configuration | Value for this application |
|---|---|
| Single sign-on URL / ACS | `https://approvals.example.internal/auth/acs` |
| Audience URI / SP Entity ID | `https://approvals.example.internal/saml/metadata` |
| SAML binding | HTTP-POST for assertion consumer |
| Response / assertion signing | **Sign the Assertion**, RSA-SHA256; SHA-256 digest |
| SP-initiated flow | Enabled. **IdP-initiated unsolicited responses are not supported.** |
| Name ID format | Unspecified, with an appropriate username/email NameID |
| App assignments | Assign **only** the intended requester/approver/admin groups |

> Okta Admin screens differ across Okta Identity Engine and Classic Engine. The application specifically expects **an XML-signed assertion**, not just an HTTP transport or an unsigned assertion. If Okta is configured to require signed AuthnRequests, this reference SP will not authenticate: it sends **unsigned AuthnRequests**. Configure the Okta custom app to accept unsigned AuthnRequests or add properly secured SP signing certificates and signed requests in a separate implementation.

Create three dedicated **Okta groups** (example names):

- `Prod-Automation-Requester` — submit production requests; trigger own requests after approval.
- `Prod-Automation-Approver` — review/approve/reject other users' requests; trigger approved requests.
- `Prod-Automation-Admin` — submit and approve **other users'** requests and trigger approved requests.

In the SAML app **Attribute Statements**, create attributes with these exact **Name** values (case sensitive):

| Attribute Name | Okta expression / value | Requirement |
|---|---|---|
| `oktaUserId` | `user.getInternalProperty("id")` | **Required:** immutable Okta user ID, not email, preventing identity confusion if email addresses change. Must be one value, e.g. `00u...`. |
| `displayName` | `user.firstName + " " + user.lastName` | Optional, friendly display name. |

In **Group Attribute Statements**, add an attribute named exactly **`groups`**, filtered to the approval groups. For example, if your Okta UI supports `Matches regex`, use:

```regex
^Prod-Automation-(Requester|Approver|Admin)$
```

Group membership is sent as **separate SAML attribute values**. Group-to-portal role matching is an **exact, case-sensitive match**. The portal does **not** accept a self-asserted `role` claim, or derive role from email domain; it denies sign-in when no mapped group is present.

Obtain these details under your Okta SAML app's **View SAML setup instructions** / **Sign On** tab:

1. **Identity Provider Single Sign-On URL** -> `OKTA_SAML_SSO_URL`.
2. **Identity Provider Issuer** -> `OKTA_SAML_IDP_ENTITY_ID` (often `http://www.okta.com/...`; the issuer is an identifier, not an endpoint).
3. **X.509 Certificate** -> Azure Key Vault secret `portal-okta-signing-cert` (PEM text including BEGIN/END certificate headers is supported). The `app/saml_auth.py` loader accepts PEM or the certificate's base64 DER body; no IdP certificate fingerprints are accepted.

For the Okta tile: this SP deliberately rejects **IdP-initiated** sign-in. Use an Okta **Bookmark App** linking to `https://approvals.example.internal/login`, or have users navigate directly to that URL (SP-initiated), instead of launching the SAML app as an IdP-initiated tile.

If the certificate is rotated in Okta, replace the pinned certificate in Key Vault and coordinate a fresh pod rollout with the new certificate. Schedule rotations to avoid partial pod fleets trusting different certificates.

## 2. Update the configuration

Edit `deploy/03-settings.yaml`:

```yaml
PUBLIC_BASE_URL: "https://approvals.example.internal"
OKTA_SAML_SSO_URL: "https://YOUR_ORG.okta.com/app/YOUR_APP/sso/saml"
OKTA_SAML_IDP_ENTITY_ID: "http://www.okta.com/YOUR_IDP_IDENTIFIER"
OKTA_GROUP_REQUESTER: "Prod-Automation-Requester"
OKTA_GROUP_APPROVER: "Prod-Automation-Approver"
OKTA_GROUP_ADMIN: "Prod-Automation-Admin"
ACTIONS_PATH: "/app/actions.yaml"
SECRETS_DIR: "/mnt/secrets"
```

Replace the placeholders with **real** Okta values. Do **not** carry forward `ENTRA_CLIENT_ID`, `ENTRA_CLIENT_SECRET`, `ENTRA_TENANT_ID`, or `ENTRA_AUTHORITY` as login settings — they were removed. You must still configure `tenantId` in `deploy/02-secretproviderclass.yaml` to match the **Azure Key Vault tenant** used by Workload Identity, not the Okta organization.

Edit `deploy/02-secretproviderclass.yaml`: UAMI client ID, vault name, **Azure** tenant ID, and `cloudName` (`AzurePublicCloud` in Commercial, `AzureUSGovernment` in Azure Government). Edit `deploy/01-service-account.yaml` with the UAMI client ID.

Edit `deploy/04-deployment.yaml` and `deploy/07-migrate-job.yaml` to use your ACR repository; choose a reviewed versioned image tag. Update the portal hostname in `deploy/04-deployment.yaml` probe Host headers and in `deploy/06-ingress.yaml`; supply a valid TLS certificate and appropriate ingress class.

### Azure Key Vault secrets

The portal expects these five *secrets* through the mounted CSI volume (`SECRETS_DIR=/mnt/secrets`). If only one type of automation is enabled, remove unused targets and secret entries after adjusting the implementation and your deployment configuration.

| Key Vault object name | Mounted alias / environment | Purpose |
|---|---|---|
| `portal-database-url` | `DATABASE_URL` | PostgreSQL connection with TLS, e.g. `postgresql+psycopg://USER:ENCODED_PASSWORD@HOST:5432/approvals?sslmode=verify-full` |
| `portal-session-secret` | `SESSION_SECRET` | Strong randomly generated cookie signing secret; consistent across replicas |
| **`portal-okta-signing-cert`** | **`OKTA_IDP_X509_CERT`** | Okta IdP SAML **public X.509 signing certificate** (not a client secret) |
| `portal-gitlab-token` | `GITLAB_PROJECT_TOKEN` | Least-privileged GitLab project access token (or configure trigger token as a different alias) |
| `portal-logic-app-callback` | `LOGIC_APP_CALLBACK_URL` | HTTPS Logic App Request trigger callback URL including SAS credential |

`portal-entra-client-secret` is **no longer used** by the application and should be removed from the CSI configuration; delete the old Key Vault secret after confirming no other application needs it.

Use AKS OIDC issuer / Azure workload identity for the **Key Vault CSI provider only**:

```bash
az aks update -g <AKS_RESOURCE_GROUP> -n <AKS_CLUSTER> --enable-oidc-issuer --enable-workload-identity
az identity create -g <RESOURCE_GROUP> -n portal-approval-uami
ISSUER=$(az aks show -g <AKS_RESOURCE_GROUP> -n <AKS_CLUSTER> --query oidcIssuerProfile.issuerUrl -o tsv)
az identity federated-credential create -g <RESOURCE_GROUP> --identity-name portal-approval-uami \
  -n portal-approvals --issuer "$ISSUER" \
  --subject system:serviceaccount:prod-automation:approval-portal \
  --audience api://AzureADTokenExchange
```

Restrict the UAMI to the dedicated Key Vault (RBAC `Key Vault Secrets User` or secret-scoped access). The pod reads the mounted files directly; no Kubernetes Secret sync is required. For Azure Government, set `az cloud set --name AzureUSGovernment`, use the government Key Vault cloud in CSI, and ensure your AKS egress can reach **your Okta tenant**.

## 3. Configure GitLab and Logic App actions

`actions.yaml` contains allowlisted production actions. Review the target and values in Git. The supplied example triggers the main GitLab orchestration branch with these values:

```
PIPELINE_TYPE=deploy
DEPLOY_ENV=prod
PACKAGE_VERSION=<requested version>
CHANGE_TICKET=<change ticket>
APPROVAL_REQUEST_ID=<approval UUID>
```

- `auth_mode: pipeline_api` (GitLab project access token): `POST https://GITLAB_HOST/api/v4/projects/:id/pipeline` with `PRIVATE-TOKEN` header and JSON variables.
- `auth_mode: trigger_api` (GitLab **pipeline trigger** token, not a project token): `POST .../api/v4/projects/:id/trigger/pipeline` with form fields.
- Logic App: JSON POST to callback URL stored securely in Key Vault; the provided example request schema is in `examples/logic-app-request-schema.json`.

Only allowlisted actions may execute. The app stores a SHA-256 fingerprint for the selected action when a requester submits; changing its definition invalidates requests awaiting approval or execution. Users cannot change the destination URL, project, ref, pipeline variables or environment from the UI.

**Do not trust the portal as the sole approval gate** if users can directly run the same protected production GitLab pipeline or Logic App URL using their own credentials. Enforce protected environments, deployment credentials and input guards at the automation endpoints too. Accepted HTTP responses are **not** proof of a successful release.


## 3A. Dashboard v3: prioritized approval queue and execution monitoring

The dashboard now begins with four clickable, database-backed cards: **Pending approvals** (`status=pending`), **Approved / ready** (`status=approved`, decided within the past 24 hours, not yet triggered), **Running automations** (`execution_status=running`), and **Failed deployments** (`execution_status=failed`). Each card filters the history table. Counts span all database records visible to the signed-in user, **not** the 200-row recent history limit. Approvers see a separate **priority approval queue** (oldest first, max 15) that hides their own requests. The pending counter also includes their own pending requests; the queue intentionally does not. Requesters see their pending requests but cannot approve them. The existing change request form appears below the queue.

**Execution state is independent of change approval state.** After an upstream HTTP 2xx response, the approval stays `submitted`; a successful HTTP call is not treated as a successful release. `dispatch_uncertain` remains terminal and is **never retried automatically**. The run status is updated only from GitLab read API responses or explicit Logic App operator attestation; new status transitions produce `approval_audit` events. The dashboard shows timestamps of the last successful check; a stale state is the **last known** result, not a live guarantee.

### GitLab status polling

1. Deploy `deploy/09-gitlab-status-cronjob.yaml` using the same reviewed image, action allowlist, and Key Vault CSI setup as the portal. The CronJob polls up to 15 **non-final** GitLab pipelines per run, every two minutes; tune `GITLAB_SYNC_LIMIT` (1–100) alongside the CronJob deadline/network capacity if needed. A new deployment is **not** triggered by status monitoring.
2. For `auth_mode: pipeline_api`, the configured `token_env` is used to read `GET /api/v4/projects/:id/pipelines/:pipeline_id`, unless `status_token_env` overrides it. Protect this token in Key Vault and give it the minimum API read permissions required by the GitLab project.
3. For `auth_mode: trigger_api`, a pipeline **trigger token cannot read pipeline status**. Add `status_token_env: GITLAB_STATUS_TOKEN` in that action definition and mount a separate project/group access token that is allowed to read the pipeline, e.g. add a Key Vault CSI object mapping to that environment alias. Without one, the run remains **last-known pending** and will not appear as running/failed; don't confuse this with a confirmed result.
4. Only numeric pipeline IDs returned by the fixed GitLab trigger target can be queried. Poll requests are restricted to the reviewed action allowlist and hostname; changed action fingerprints are ignored to avoid querying a different destination. `success -> succeeded`, `failed -> failed`, `running -> running`; canceled and skipped outcomes have distinct states. Transitions and background-sync actions are auditable.

Example status monitor access token in `deploy/02-secretproviderclass.yaml` when using GitLab trigger API:

```yaml
        - |
          objectName: portal-gitlab-status-token
          objectAlias: GITLAB_STATUS_TOKEN
          objectType: secret
```

### Logic App execution reconciliation

A successful HTTP 200/202 response to a Logic App Request trigger **only records `submitted` / `unknown`**. This release does **not** assume that a Logic App Standard/Consumption workflow run has finished and does not attempt to infer success from callback headers. An Okta **Approver/Admin other than the requester** can open **Request Details → Record verified execution result**, inspect the Azure Logic App run history and attest `Running`, `Succeeded` or `Failed` with a mandatory Azure run ID/evidence note (20–400 chars). The verification writes an audit event. Once final (`succeeded` or `failed`), it cannot be overwritten through the portal; an intermediate `running` result can later be finalized. For full automatic Logic App status, add a workload-identity-based **read-only** Azure management/data-plane integration using the correct Logic App hosting model before removing manual attestation.

**Operator caveats:** This v3 dashboard does not constitute an immutable audit ledger, continuous status stream, or automated Logic App run monitor. Ensure the status CronJob completes, monitor its error logs, review pipeline permissions in GitLab, and export important approvals/execution events to an immutable audit or SIEM destination. The status poller's pod shares the current Key Vault-mounted secrets and service account; harden privileges/egress separately if stricter separation is needed.

## 4. Build and deploy to AKS

### Existing deployment — preserve PostgreSQL data

The v3 schema requires **two additive migrations** when upgrading from v1, and only **migration 002** when upgrading from Okta v2. Run the reviewed SQL against PostgreSQL using a controlled migration account (do not expose DB credentials in Git):

```bash
# Run 001 only if this database has not had the v2 Okta SAML migration.
psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -f migrations/001_okta_saml_login_requests.sql

# Required for EVERY existing v1/v2 installation updating to v3:
psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -f migrations/002_execution_tracking.sql
```

Do not delete or recreate the production database. Existing approval rows remain; the historical requester/approver IDs contain Entra IDs, whereas new users have IDs like `okta:00u...`. **No existing Entra identity is implicitly mapped to an Okta identity**: outstanding approvals should be reviewed and closed/recreated during the transition. If preserving workflow ownership from Entra matters, perform a separate, audited person-by-person identity migration before cutover; this package does not guess mappings. Avoid switching back and forth between Entra v1 and Okta v2/v3 (incompatible session and identity semantics).

### Build and rollout

```bash
# From repository root, after editing the manifests and Okta configuration:
az acr build --registry <ACR_NAME> --image approval-portal:3.0.0 .

kubectl apply -f deploy/00-namespace.yaml
kubectl apply -f deploy/01-service-account.yaml
kubectl apply -f deploy/02-secretproviderclass.yaml
kubectl apply -f deploy/03-settings.yaml

kubectl -n prod-automation create configmap approval-actions \
  --from-file=actions.yaml=./actions.yaml --dry-run=client -o yaml | kubectl apply -f -

# FRESH database only: create the schema with the included bootstrap Job.
# For existing installations use the SQL migration above instead.
# kubectl apply -f deploy/07-migrate-job.yaml
# kubectl -n prod-automation wait --for=condition=complete job/approval-portal-db-bootstrap --timeout=180s

kubectl apply -f deploy/04-deployment.yaml
kubectl apply -f deploy/05-service.yaml
kubectl apply -f deploy/06-ingress.yaml
kubectl apply -f deploy/09-gitlab-status-cronjob.yaml
kubectl -n prod-automation rollout status deploy/approval-portal
kubectl -n prod-automation get pods,svc,ingress,cronjobs
```

The Dockerfile builds `lxml` and `xmlsec` from source against **the same system libxml2 version** in a builder stage, and checks toolkit imports in the final runtime image. SAML signature verification can fail if `lxml` and `xmlsec` link incompatible libxml2 versions; run a real signed Okta sign-in integration test after any image/dependency update. You also need appropriate ACR image-pull permissions.

Recommended: **private NGINX ingress** over TLS, restrict DNS/entry points to corporate access, apply a reviewed NetworkPolicy and firewall egress to Okta, PostgreSQL, GitLab and Logic Apps. If your self-hosted GitLab uses an internal CA, mount and use the corporate CA bundle (`OUTBOUND_CA_BUNDLE`); do not disable TLS validation. Ingress uses `proxy-body-size: 128k` because group claims can make SAML POST bodies exceed 16 KiB; the application also rejects POST bodies over 128 KiB. Ensure Ingress does not rewrite `/auth/acs` or modify its SAML POST body.

## 5. Test the SAML login and approval separation

1. Open `https://approvals.example.internal/saml/metadata` and verify SP Entity ID, ACS URL, HTTP-POST binding match your Okta integration.
2. Navigate to `https://approvals.example.internal/login`. The browser should redirect **to your Okta tenant's SAML login URL**.
3. Sign in as an Okta `Prod-Automation-Requester` member. Okta posts the signed response to `/auth/acs`. The portal verifies signature/audience/destination/issuer/timing, the `InResponseTo` login ID, an unpredictable matching RelayState and a one-time PostgreSQL record. The resulting dashboard shows Requester permissions.
4. Submit a production request. A **different** Okta `Prod-Automation-Approver` signs in and approves it; confirm the requester cannot approve it themselves (even when also in Approver/Admin).
5. Trigger after approval. A GitLab pipeline with a returned ID is polled by the status CronJob; verify the dashboard transitions to Running/Failed/Succeeded. For Logic Apps, inspect the Azure run history and have a separate Okta Approver/Admin record Running, Succeeded, or Failed with evidence on the request detail page.
6. Confirm a POST to `/auth/acs` without an earlier GET `/login` fails; replaying a consumed assertion should fail. Sign-in without a mapped group or without `oktaUserId` must fail.
7. Confirm `APPROVED` requests expire after 24 hours; `SUBMITTED` or `DISPATCH_UNCERTAIN` cannot be triggered a second time.

SAML POST occurs from **Okta's site to the portal's site**, so the session cookie uses `SameSite=None`, `Secure`, `HttpOnly` for the brief correlation round trip. The portal uses a separate CSRF token for all non-ACS state-changing POST operations. Correlation cookies are HMAC-signed, not encrypted, and remain valid for a maximum 30-minute session; login correlations expire in five minutes and are stored and consumed centrally in PostgreSQL. SP-initiated **only**; no unsolicited SAML response support. `/logout` clears the local app session but **does not sign the user out of Okta globally**.

## 6. Security and operational notes

- **Signature/metadata:** Only trust a reviewed, pinned Okta certificate held in Key Vault. The SAML toolkit is configured with `strict=True`, signed assertions required, SHA-256 signature/digest, rejection of deprecated algorithms, issuer/audience/recipient checks, and SP-initiated request ID correlation. Certificate rollover must be orchestrated. **Never** accept arbitrary user-supplied IdP metadata or disable signature validation.
- **Immutable identity:** A signed `oktaUserId` from `user.getInternalProperty("id")` is mandatory; email/display name cannot be used to override the principal. This ID is stored with the `okta:` prefix for separation from old Entra users.
- **Roles and revocation:** Permissions come from exact Okta SAML `groups` attribute values. Role/group changes take effect when the user signs in again; a signed app session can remain active for up to 30 minutes. **Immediate revocation requires additional centralized session invalidation/revalidation**, which is not implemented here. Configure Okta MFA, phishing-resistant authenticators and access policies appropriate for production approvals.
- **Audit:** App-generated events are not protected from a PostgreSQL administrator altering them. Stream audit to a SIEM/immutable store and establish retention policy, DB backups/PITR and monitoring.
- **Automation credentials:** Least-privileged GitLab service/project token; protect GitLab prod refs and environments. Keep Logic App callback tokens in Key Vault; rotate safely. Never store secrets in ConfigMaps or UI inputs.
- **Network:** Keep ingress private; use firewall restrictions, internal TLS/hop-level mTLS where needed. Workload Identity still requires correct AKS issuer federated credential and Azure tenant ID for Key Vault, regardless of Okta user login.
- **One-time dispatch:** The approval row is atomically locked into `dispatching` before the target POST. HTTP timeout might still mean upstream started; errors become `dispatch_uncertain`, requiring human reconciliation. There is no automatic retry.
- **Database:** The first deployment can bootstrap schema with `Base.metadata.create_all`; use versioned controlled migration SQL for updates. On-login cleanup removes SAML login correlation records older than one day; approval audit history is not purged.
- **Build/security review:** Scan Python dependencies and image with your security gate, pin image by immutable digest, keep the base image/OS libraries patched, and run integration tests with signed Okta assertions. Specifically validate libxml2/lxml/xmlsec compatibility at image build time.

## Tests (local, no Okta credentials required for unit tests)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt pytest
pytest -q
```

The tests cover *claim mapping, group authorization, settings, SP-initiated browser/relay/replay routes with a mocked SAML verifier, and dispatcher logic*. They do **not** replace integration tests with signed SAML Responses, real Okta configuration, AKS ingress and PostgreSQL, and outbound GitLab/Logic App API acceptance. Locally running the full web portal requires PostgreSQL, five secrets, the Okta SAML settings and HTTPS via a reverse proxy:

```bash
export PUBLIC_BASE_URL='https://approvals.example.internal'
export OKTA_SAML_SSO_URL='https://YOUR_ORG.okta.com/app/YOUR_APP/sso/saml'
export OKTA_SAML_IDP_ENTITY_ID='http://www.okta.com/YOUR_IDP_ID'
export OKTA_GROUP_REQUESTER='Prod-Automation-Requester'
export OKTA_GROUP_APPROVER='Prod-Automation-Approver'
export OKTA_GROUP_ADMIN='Prod-Automation-Admin'
# DATABASE_URL, SESSION_SECRET, OKTA_IDP_X509_CERT and dispatch secrets via
# Key Vault CSI mounts or process environment in local test (never commit them).
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

### References

- Okta SAML group attribute statement configuration: https://help.okta.com/oie/en-us/content/Topics/apps/define-group-attribute-statements.htm
- Okta immutable user ID expression: https://developer.okta.com/docs/reference/okta-expression-language/
- python3-saml toolkit and security configuration: https://github.com/SAML-Toolkits/python3-saml
- GitLab API for creating pipelines: https://docs.gitlab.com/api/pipelines/
- GitLab API for trigger tokens: https://docs.gitlab.com/ci/triggers/
- Azure AKS Key Vault CSI / Workload Identity: https://learn.microsoft.com/en-us/azure/aks/csi-secrets-store-identity-access
- Azure Logic Apps trigger security: https://learn.microsoft.com/en-us/azure/logic-apps/logic-apps-securing-a-logic-app
