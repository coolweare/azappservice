"""Generate optional example dashboard screenshot with DEMO records only.
Run from repo root: python docs/render_preview.py
"""
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

from jinja2 import Environment, FileSystemLoader, select_autoescape
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
templates = root / 'app/templates'
actions = {
    'web_deploy_prod': SimpleNamespace(label='Deploy web application to production', kind='gitlab'),
    'logicapp_deploy_prod': SimpleNamespace(label='Execute production Logic App workflow', kind='logic_app'),
}

def approval(key, idx, status, exec_status=None, name='Taylor Brooks', version='v2.7.12', ticket='CHG-2026-1042'):
    return SimpleNamespace(
        id=f'{idx:08d}-81e2-4f56-8a90-abcd1234ef56',
        created_at=datetime(2026, 10, 19, 14, 30-idx, tzinfo=timezone.utc),
        decided_at=datetime(2026, 10, 19, 13, 0, tzinfo=timezone.utc) if status == 'approved' else None,
        action_key=key, requester_oid=f'okta:some-other-{idx}', requester_name=name,
        package_version=version, change_ticket=ticket, status=status, execution_status=exec_status,
        execution_checked_at=datetime(2026, 10, 19, 15, 30, tzinfo=timezone.utc) if exec_status in ('running', 'failed', 'succeeded') else None,
        upstream_run_url='https://gitlab.example.internal/group/project/-/pipelines/1082' if key == 'web_deploy_prod' and status == 'submitted' else None,
    )

queue = [
    approval('web_deploy_prod', 1, 'pending', name='Taylor Brooks'),
    approval('logicapp_deploy_prod', 2, 'pending', name='Jordan Miller', version='v1.6.3', ticket='CHG-2026-1040'),
    approval('web_deploy_prod', 3, 'pending', name='Morgan Lee', version='v2.7.11', ticket='CHG-2026-1037'),
]
rows = queue + [
    approval('logicapp_deploy_prod', 4, 'approved', name='Riley Chen', ticket='CHG-2026-1036'),
    approval('web_deploy_prod', 5, 'submitted', 'running', name='Cameron Parker', ticket='CHG-2026-1031'),
    approval('web_deploy_prod', 6, 'submitted', 'failed', name='Alex Kim', ticket='CHG-2026-1029'),
    approval('logicapp_deploy_prod', 7, 'submitted', 'unknown', name='Casey Thomas', ticket='CHG-2026-1024'),
]
env = Environment(loader=FileSystemLoader(str(templates)), autoescape=select_autoescape(['html']))
html = env.get_template('index.html').render(
    user={'name':'Casey Rivera', 'oid': 'okta:approver-user', 'roles':['Requester', 'Approver']},
    csrf='demo-only', actions=actions, approvals=rows, queue=queue,
    cards={'pending':3, 'approved':2, 'running':1, 'failed':1},
    view='all', is_approver=True, notice=None, is_expired=lambda _: False,
)
css=(root/'app/static/style.css').read_text()
html=html.replace('<link rel="stylesheet" href="/static/style.css">', f'<style>{css}</style>')
html=html.replace('<title>Production Automation Approvals</title>', '<title>PROTOTYPE — Sample data — Production Automation Approvals</title>')
html=html.replace('<main>', '<main><p class="notice" role="note">DEMO PREVIEW — example data only; not connected to a live Okta, AKS, GitLab, or Logic App environment.</p>', 1)
(root/'docs/dashboard-preview.html').write_text(html, encoding='utf-8')
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1440,'height':900}, device_scale_factor=1)
    page.set_content(html, wait_until='load')
    page.screenshot(path=str(root/'docs/dashboard-preview.png'), full_page=True)
    browser.close()
print(root/'docs/dashboard-preview.png')
