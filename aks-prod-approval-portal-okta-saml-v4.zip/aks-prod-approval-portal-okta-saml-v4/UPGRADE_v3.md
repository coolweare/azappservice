# Update Okta SAML Approval Portal v2 -> v3 (AKS)

**New:** four linked operational status cards; prioritized approval queue; execution-state tracking; GitLab status CronJob; manual, evidence-based Azure Logic App run reconciliation. SAML sign-in/Okta group permissions and existing production automation allowlist remain unchanged.

## Existing PostgreSQL database: apply additive schema update

Review `migrations/002_execution_tracking.sql` and back up the database before any schema change. Run **002 only** if you already installed the Okta v2 schema:

```bash
psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/002_execution_tracking.sql
```

If updating directly from Entra v1, review and apply migration `001_okta_saml_login_requests.sql` first, configure Okta group IDs and signing certificate, then apply 002. Do not rerun the bootstrap Job against an existing production database.

## Build and deploy new image

After editing your environment-specific `deploy/*.yaml` values and reviewing `actions.yaml`:

```bash
az acr build --registry <ACR_NAME> --image approval-portal:3.0.0 .

# If you changed the reviewed allowlist, re-apply its ConfigMap.
kubectl -n prod-automation create configmap approval-actions \
  --from-file=actions.yaml=./actions.yaml --dry-run=client -o yaml | kubectl apply -f -

kubectl apply -f deploy/04-deployment.yaml
kubectl apply -f deploy/09-gitlab-status-cronjob.yaml
kubectl -n prod-automation rollout status deployment/approval-portal
kubectl -n prod-automation get cronjob/approval-portal-status-sync
```

The v3 image tag must be changed to your actual ACR hostname in both Deployment and CronJob manifests. Keep your existing Okta ConfigMap, CSI SecretProviderClass, Service, Ingress and namespace unless their details are intentionally changed.

## GitLab status permissions

For `auth_mode: pipeline_api`, the project access token in `GITLAB_PROJECT_TOKEN` may be reused for GitLab pipeline status reads, or use `status_token_env` to specify a separate credential. For `auth_mode: trigger_api`, add **`status_token_env: GITLAB_STATUS_TOKEN`** to the relevant GitLab action in `actions.yaml`, and provision the corresponding Key Vault CSI alias for a separate status-read-capable token. Pipeline trigger tokens cannot read execution status.

```yaml
# Under the GitLab action, when auth_mode: trigger_api:
status_token_env: GITLAB_STATUS_TOKEN
```

Test the poller manually after deploying, then inspect recent job logs:

```bash
kubectl -n prod-automation create job --from=cronjob/approval-portal-status-sync approval-status-test-001
kubectl -n prod-automation wait --for=condition=complete job/approval-status-test-001 --timeout=360s
kubectl -n prod-automation logs job/approval-status-test-001
```

The CronJob polls a bounded number of pipelines (default 15) every ~2 minutes. Status failures are logged without token content and do not trigger retries of production changes.

## Logic Apps and audit

An HTTP 200/202 only proves acceptance, **not** workflow completion. For Logic App actions, a different Okta Approver/Admin can open a request and record `Running`, `Succeeded` or `Failed` with a run-history evidence note. These updates generate audit events; final states are write-once. The solution does **not** yet automatically poll Azure Logic Apps Standard or Consumption execution state.

## Validation

```bash
pip install -r requirements.txt pytest
pytest -q
```

Before switching production traffic, also test actual signed Okta SAML assertions, both approval roles, CSRF and self-approval denial, GitLab/Logic App destinations, database migration, AKS Secret Store CSI, and the CronJob against a staging deployment. This is a reference implementation, not a production-certified application.
