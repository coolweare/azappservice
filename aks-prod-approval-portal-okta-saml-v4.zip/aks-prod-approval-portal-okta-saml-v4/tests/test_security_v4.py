"""Additional security regression tests; real Okta, Azure and GitLab require integration testing."""
import base64
import hashlib
import importlib
import time
from datetime import timedelta

import jwt
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import (
    Encoding, PrivateFormat, PublicFormat, NoEncryption
)
from test_saml_routes import portal


@pytest.fixture
def rsa_signer(monkeypatch):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private = key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()).decode()
    public = key.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo).decode()
    monkeypatch.setenv('APPROVAL_SIGNING_PRIVATE_KEY', private)
    monkeypatch.setenv('APPROVAL_SIGNING_KID', 'test-key-1')
    monkeypatch.setenv('GATE_GITLAB_TOKEN', 'test-gate-secret-never-use-in-prod')
    monkeypatch.setenv('GATE_LOGICAPP_TOKEN', 'other-test-gate-secret')
    return public


def test_server_side_session_revocation_and_expiry(portal):
    from app.security_controls import create_session, get_session, revoke_user
    principal = {'oid': 'okta:00uABCDEFG123456789', 'name': 'Alice', 'roles': ['Approver']}
    token = create_session(principal)
    assert get_session(token)['roles'] == ['Approver']
    assert revoke_user('00uABCDEFG123456789') == 1
    assert get_session(token) is None
    assert get_session('fake') is None


def test_group_removed_okta_hook_revokes_existing_sessions(portal):
    from app.security_controls import create_session, get_session
    from app.okta_events import process_event_hook
    principal = {'oid': 'okta:00uABCDEFG123456789', 'name': 'Bob', 'roles': ['Admin']}
    cookie = create_session(principal)
    batch = {'data': {'events': [{
        'eventType': 'group.user_membership.remove',
        'target': [{'type': 'User', 'id': '00uABCDEFG123456789'}]
    }]}}
    assert process_event_hook(batch) == 1
    assert get_session(cookie) is None
    assert process_event_hook(batch) == 0


def test_atomic_rate_limit_across_repeated_calls(portal):
    from app.security_controls import enforce_rate_limit
    enforce_rate_limit('test-client', 2)
    enforce_rate_limit('test-client', 2)
    with pytest.raises(HTTPException) as exc:
        enforce_rate_limit('test-client', 2)
    assert exc.value.status_code == 429


def test_attestation_rs256_binds_project_ref_and_resists_tampering(portal, rsa_signer):
    from app import db, main
    from app.config import action_fingerprint
    from app.approval_attestation import build_attestation, verify_attestation
    action = main.ACTIONS['web_deploy_prod']
    request = db.Approval(id='11111111-2222-3333-4444-555555555555',
                          action_key='web_deploy_prod', action_hash=action_fingerprint(action),
                          package_version='v4.0.0', change_ticket='CHG-2026-1042',
                          requester_oid='okta:00uREQUESTER', requester_name='requester',
                          decided_by_oid='okta:00uAPPROVER', decided_at=db.utcnow(), status='dispatching',
                          reason='A planned deployment')
    attestation = build_attestation(request, action)
    verified = verify_attestation(attestation, rsa_signer, 'prod-automation:gitlab')
    assert verified['project_id'] == str(action['project_id'])
    assert verified['ref'] == action['ref']
    assert verified['package_version'] == 'v4.0.0'
    with pytest.raises(jwt.InvalidTokenError):
        verify_attestation(attestation, rsa_signer, 'prod-automation:logic_app')
    with pytest.raises(jwt.InvalidTokenError):
        verify_attestation(attestation[:-6]+'123456', rsa_signer, 'prod-automation:gitlab')
    request.decided_by_oid = request.requester_oid
    with pytest.raises(ValueError, match='own requests'):
        build_attestation(request, action)


def test_attestation_one_time_gate_rejects_replay_and_wrong_approver(portal, rsa_signer):
    from app import db, main
    from app.config import action_fingerprint
    from app.approval_attestation import build_attestation
    action = main.ACTIONS['web_deploy_prod']
    with db.SessionLocal.begin() as session:
        row = db.Approval(action_key='web_deploy_prod', action_hash=action_fingerprint(action),
            package_version='v4.0.0', change_ticket='CHG-2026-1042',
            requester_oid='okta:00uREQUESTER', requester_name='R', reason='Test approval reason',
            decided_by_oid='okta:00uAPPROVER', decided_by_name='A',
            decided_at=db.utcnow(), status='dispatching')
        session.add(row)
        session.flush()
        proof = build_attestation(row, action)
    with TestClient(main.app, base_url='https://approvals.example.internal') as client:
        auth = {'x-approval-gate-token': 'test-gate-secret-never-use-in-prod'}
        res = client.post('/api/attestations/consume', headers=auth, json={'attestation': proof})
        assert res.status_code == 200, res.text
        assert res.json()['allowed'] is True
        assert client.post('/api/attestations/consume', headers=auth, json={'attestation': proof}).status_code == 409
        assert client.post('/api/attestations/consume', headers={'x-approval-gate-token': 'bad'},
                           json={'attestation': proof}).status_code == 401


def test_postgres_tls_downgrade_rejected(monkeypatch):
    monkeypatch.setenv('DATABASE_URL', 'postgresql+psycopg://u:p@db.example.net:5432/x?sslmode=require')
    from app import db
    with pytest.raises(RuntimeError, match='verify-full'):
        db.get_engine()


def test_logicapp_direct_sas_url_is_rejected(portal, monkeypatch, rsa_signer):
    from app import db
    from app import dispatcher
    from app.config import action_fingerprint
    action = {'kind': 'logic_app', 'require_attestation': True,
              'gateway_host': 'prod-apim.example.internal',
              'callback_url_env': 'LOGIC_APP_CALLBACK_URL', 'payload': {'packageVersion': '{package_version}'}}
    monkeypatch.setenv('LOGIC_APP_CALLBACK_URL', 'https://logic.azure.com/run?sig=SASKEY')
    approval = db.Approval(id='11111111-2222-3333-4444-555555555556',
          action_key='logicapp_deploy_prod', action_hash=action_fingerprint(action),
          package_version='v4.0.0', change_ticket='CHG-2026-1042',
          requester_oid='okta:00uREQUESTER', requester_name='R',
          decided_by_oid='okta:00uAPPROVER', decided_at=db.utcnow(), status='dispatching', reason='Reason')
    with pytest.raises(dispatcher.DispatchError, match='APIM gateway'):
        dispatcher.dispatch(action, approval)
