import pytest
from app.config import load_actions, require_https, substitute, action_fingerprint


def test_action_allowlist_and_fingerprints():
    actions = load_actions("actions.yaml")
    assert set(actions) == {"web_deploy_prod", "logicapp_deploy_prod"}
    assert action_fingerprint(actions["web_deploy_prod"]) != action_fingerprint(actions["logicapp_deploy_prod"])


def test_expand_only_approved_placeholders():
    result = substitute({"package": "{package_version}", "id": "{request_id}", "env": "prod"},
                        {"package_version": "v1.2.3", "change_ticket": "CHG-17", "request_id": "abc"})
    assert result == {"package": "v1.2.3", "id": "abc", "env": "prod"}


def test_https_required():
    with pytest.raises(ValueError):
        require_https("http://example.com/path")
    with pytest.raises(ValueError):
        require_https("https://user:pass@example.com/")


def test_reject_unknown_placeholder(tmp_path):
    target = tmp_path / "actions.yaml"
    target.write_text('actions:\n  a1:\n    kind: logic_app\n    label: demo\n    callback_url_env: APP_URL\n    payload: {x: "{evil}"}\n')
    with pytest.raises(ValueError):
        load_actions(str(target))
