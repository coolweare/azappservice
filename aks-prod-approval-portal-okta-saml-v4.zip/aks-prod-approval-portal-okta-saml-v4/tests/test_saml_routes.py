"""Route-flow tests with a fake SAML verifier; signed XML must be tested with Okta."""
import base64
import importlib
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def portal(tmp_path, monkeypatch):
    monkeypatch.setenv('APP_ENV', 'test')
    monkeypatch.setenv('DATABASE_URL', f'sqlite:///{tmp_path}/test.db')
    monkeypatch.setenv('SESSION_SECRET', 'test-session-secret-do-not-use-in-prod')
    monkeypatch.setenv('PUBLIC_BASE_URL', 'https://approvals.example.internal')
    monkeypatch.setenv('ACTIONS_PATH', 'actions.yaml')
    monkeypatch.setenv('OKTA_SAML_SSO_URL', 'https://tenant.okta.com/app/abc/sso/saml')
    monkeypatch.setenv('OKTA_SAML_IDP_ENTITY_ID', 'http://www.okta.com/abc')
    monkeypatch.setenv('OKTA_IDP_X509_CERT', base64.b64encode(b'\x30' + b'X'*500).decode())
    monkeypatch.setenv('OKTA_GROUP_REQUESTER', 'Prod-Automation-Requester')
    monkeypatch.setenv('OKTA_GROUP_APPROVER', 'Prod-Automation-Approver')
    monkeypatch.setenv('OKTA_GROUP_ADMIN', 'Prod-Automation-Admin')
    from app import db
    db = importlib.reload(db)
    db.Base.metadata.create_all(db.engine)
    from app import security_controls, okta_events
    importlib.reload(security_controls)
    importlib.reload(okta_events)
    from app import main
    main = importlib.reload(main)

    class FakeSAML:
        def __init__(self, post_data):
            self.post_data = post_data
            self.id = 'id' + self.post_data.get('SAMLResponse', 'login')
            self.request_id = None

        def login(self, return_to):
            return 'https://tenant.okta.com/app/abc/sso/saml?RelayState=' + return_to

        def get_last_request_id(self):
            return 'id-fake-request'

        def process_response(self, request_id):
            self.request_id = request_id

        def get_errors(self):
            return []

        def is_authenticated(self):
            return True

        def get_last_response_in_response_to(self):
            return self.request_id if self.post_data.get('SAMLResponse') == 'valid' else 'wrong-request'

        def get_attributes(self):
            return {'oktaUserId': ['00uABCDEF1234567890'],
                    'groups': ['Prod-Automation-Requester'], 'displayName':['Test Requester']}

        def get_nameid(self):
            return 'requester@example.org'

    monkeypatch.setattr(main, 'new_auth', lambda base, path, config, data=None: FakeSAML(data or {}))
    return main


def test_no_idp_initiated_saml_allowed(portal):
    with TestClient(portal.app, base_url='https://approvals.example.internal') as client:
        result = client.post('/auth/acs', data={'SAMLResponse': 'valid', 'RelayState': 'bad'})
        assert result.status_code == 401


def test_login_requires_matching_relay_and_consumes_once(portal):
    with TestClient(portal.app, base_url='https://approvals.example.internal') as client:
        login = client.get('/login', follow_redirects=False)
        assert login.status_code == 302
        relay = parse_qs(urlparse(login.headers['location']).query)['RelayState'][0]
        signed_cookie = client.cookies.get('approval_session')
        assert 'secure' in login.headers['set-cookie']
        assert 'samesite=none' in login.headers['set-cookie']
        bad = client.post('/auth/acs', data={'SAMLResponse': 'valid', 'RelayState':'attacker'}, follow_redirects=False)
        assert bad.status_code == 401
        bad_req = client.post('/auth/acs', data={'SAMLResponse': 'bad-in-response-to', 'RelayState':relay}, follow_redirects=False)
        assert bad_req.status_code == 401
        ok = client.post('/auth/acs', data={'SAMLResponse':'valid','RelayState':relay}, follow_redirects=False)
        assert ok.status_code == 303
        assert ok.headers['location'] == '/'
        home = client.get('/')
        assert home.status_code == 200
        assert 'Test Requester' in home.text
        # Restore the PRE-auth cookie to simulate a captured old SAML POST.
        client.cookies.set('approval_session', signed_cookie, domain='approvals.example.internal', path='/')
        replay = client.post('/auth/acs', data={'SAMLResponse':'valid','RelayState':relay}, follow_redirects=False)
        assert replay.status_code == 401
