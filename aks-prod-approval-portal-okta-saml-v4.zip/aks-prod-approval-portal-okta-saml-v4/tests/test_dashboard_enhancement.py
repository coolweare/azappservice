"""Dashboard counts, approval queue, status polling and attested Logic App results."""
from datetime import timedelta
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient
from test_saml_routes import portal  # reuse isolated SQLite/Okta simulator fixture


def login_as_requester(client):
    login = client.get('/login', follow_redirects=False)
    relay = parse_qs(urlparse(login.headers['location']).query)['RelayState'][0]
    response = client.post('/auth/acs', data={'SAMLResponse': 'valid', 'RelayState': relay}, follow_redirects=False)
    assert response.status_code == 303


def seed(db, **overrides):
    defaults = dict(action_key='web_deploy_prod', action_hash='a'*64,
        package_version='v3.0.0', change_ticket='CHG-2026-1234', reason='planned deployment test',
        requester_oid='okta:00uABCDEF1234567890', requester_name='Requester', status='pending')
    defaults.update(overrides)
    obj = db.Approval(**defaults)
    return obj


def test_summary_counts_are_not_limited_to_recent_rows(portal):
    from app import db
    with db.SessionLocal.begin() as session:
        session.add_all([seed(db, status='pending') for _ in range(205)])
        session.add(seed(db, status='approved', decided_at=db.utcnow()))
        session.add(seed(db, status='submitted', execution_status='running'))
        session.add(seed(db, status='submitted', execution_status='failed'))
    with TestClient(portal.app, base_url='https://approvals.example.internal') as client:
        login_as_requester(client)
        home = client.get('/')
        assert home.status_code == 200
        assert '<strong>205</strong>' in home.text  # not the 200-row limit
        assert '<strong>1</strong>' in home.text
        assert 'Awaiting review' in home.text
        assert 'Last reported running' in home.text
        assert 'Failed deployments' in home.text
        running = client.get('/?view=running')
        assert 'Run: running' in running.text
        assert 'Run: failed' not in running.text
        assert client.get('/?view=anything').status_code == 400


def test_expired_approvals_not_in_ready_card(portal):
    from app import db, main
    with db.SessionLocal.begin() as session:
        session.add(seed(db, status='approved', decided_at=db.utcnow() - timedelta(hours=25)))
        session.add(seed(db, status='approved', decided_at=db.utcnow()))
    user = {'oid': 'okta:00uABCDEF1234567890', 'roles': ['Requester'], 'name': 'Test'}
    with db.SessionLocal() as session:
        cards, _, filtered = main.dashboard_data(session, user, False, 'approved')
    assert cards['approved'] == 1
    assert len(filtered) == 1


def test_approver_queue_excludes_self_and_has_working_actions(portal, monkeypatch):
    from app import db
    import app.main as main
    user = {'oid': 'okta:00uAPPROVER', 'name': 'Different Approver', 'roles': ['Approver']}
    monkeypatch.setattr(main, 'user_or_redirect', lambda request: user)
    with db.SessionLocal.begin() as session:
        session.add(seed(db, requester_oid='okta:00uAPPROVER', change_ticket='CHG-SELF'))
        session.add(seed(db, requester_oid='okta:OTHER', change_ticket='CHG-OTHERS'))
    with db.SessionLocal() as session:
        cards, queue, rows = main.dashboard_data(session, user, True, 'all')
    assert cards['pending'] == 2
    assert len(queue) == 1
    assert queue[0].change_ticket == 'CHG-OTHERS'
    assert len(rows) == 2


class _Response:
    status_code = 200
    def __init__(self, ident, status):
        self.data = {'id': int(ident), 'status': status}
    def raise_for_status(self):
        pass
    def json(self):
        return self.data


class _Client:
    def __init__(self, result):
        self.result = result
        self.headers = None
        self.url = None
    def get(self, url, headers):
        self.url, self.headers = url, headers
        return _Response('12345', self.result)
    def __enter__(self): return self
    def __exit__(self, *args): pass


def test_gitlab_sync_transitions_record_audit(portal, monkeypatch):
    from app import db
    from app.config import action_fingerprint
    from app import status_sync
    from app import main
    monkeypatch.setattr(status_sync, 'SessionLocal', db.SessionLocal)
    monkeypatch.setattr(status_sync, '_https_client', lambda: _Client('running'))
    monkeypatch.setenv('GITLAB_PROJECT_TOKEN', 'token')
    monkeypatch.setenv("GITLAB_STATUS_READ_TOKEN", "status-read-token")
    with db.SessionLocal.begin() as session:
        row = seed(db, requester_oid='okta:OTHER', status='submitted',
                   action_hash=action_fingerprint(main.ACTIONS['web_deploy_prod']),
                   dispatched_at=db.utcnow(), execution_status='pending', upstream_run_id='12345')
        session.add(row)
        session.flush()
        request_id = row.id
    first = status_sync.sync_gitlab_runs(main.ACTIONS)
    assert first['changed'] == 1
    with db.SessionLocal() as session:
        row = session.get(db.Approval, request_id)
        assert row.execution_status == 'running'
        assert row.execution_checked_at is not None
        assert session.query(db.Audit).filter_by(approval_id=request_id, event='pipeline_status').count() == 1
    monkeypatch.setattr(status_sync, '_https_client', lambda: _Client('success'))
    second = status_sync.sync_gitlab_runs(main.ACTIONS)
    assert second['changed'] == 1
    with db.SessionLocal() as session:
        row = session.get(db.Approval, request_id)
        assert row.execution_status == 'succeeded'
        assert row.execution_completed_at is not None
    final = status_sync.sync_gitlab_runs(main.ACTIONS)
    assert final['checked'] == 0  # terminal runs not polled again


def test_gitlab_trigger_token_does_not_query_run_without_status_token(portal, monkeypatch):
    from app import status_sync
    from app import main
    client = _Client('running')
    action = dict(main.ACTIONS['web_deploy_prod'], auth_mode='trigger_api', status_token_env='')
    with pytest.raises(ValueError, match='trigger token cannot query'):
        status_sync.gitlab_status(client, action, '12345')
    assert client.url is None


def test_logic_app_outcome_requires_other_approver_and_evidence(portal, monkeypatch):
    from app import db
    from app.config import action_fingerprint
    from app import main
    user = {'oid': 'okta:00uAPPROVER', 'name': 'Approver', 'roles': ['Approver']}
    monkeypatch.setattr(main, 'user_or_redirect', lambda request: user)
    monkeypatch.setattr(main, 'csrf_check', lambda request, value: None)
    action = main.ACTIONS['logicapp_deploy_prod']
    with db.SessionLocal.begin() as session:
        row = seed(db, action_key='logicapp_deploy_prod', action_hash=action_fingerprint(action),
                   requester_oid='okta:OTHER', status='submitted', execution_status='unknown')
        own = seed(db, action_key='logicapp_deploy_prod', action_hash=action_fingerprint(action),
                   requester_oid='okta:00uAPPROVER', status='submitted', execution_status='unknown')
        session.add_all([row, own])
        session.flush()
        request_id, own_id = row.id, own.id
    with TestClient(portal.app, base_url='https://approvals.example.internal') as client:
        missing_note = client.post(f'/requests/{request_id}/verify', data={'outcome': 'succeeded', 'evidence': 'short', 'csrf': 'x'})
        assert missing_note.status_code == 400
        self_attest = client.post(f'/requests/{own_id}/verify', data={'outcome': 'succeeded', 'evidence': 'Verified in Azure run history, run xyz', 'csrf': 'x'})
        assert self_attest.status_code == 403
        done = client.post(f'/requests/{request_id}/verify', data={
            'outcome': 'failed', 'evidence': 'Verified failed state for run 12345 in Azure portal', 'csrf': 'x'},
            follow_redirects=False)
        assert done.status_code == 303
        repeat = client.post(f'/requests/{request_id}/verify', data={
            'outcome': 'succeeded', 'evidence': 'Second attempt to overwrite the first outcome', 'csrf': 'x'})
        assert repeat.status_code == 409
    with db.SessionLocal() as session:
        row = session.get(db.Approval, request_id)
        assert row.execution_status == 'failed'
        assert row.execution_note.startswith('Manually verified')
        assert session.query(db.Audit).filter_by(approval_id=request_id, event='execution_verified').count() == 1


def test_logic_app_can_be_attested_running_then_succeeded(portal, monkeypatch):
    from app import db
    from app import main
    user = {'oid': 'okta:DIFFERENT', 'name': 'Approver', 'roles': ['Approver']}
    monkeypatch.setattr(main, 'user_or_redirect', lambda request: user)
    monkeypatch.setattr(main, 'csrf_check', lambda request, value: None)
    with db.SessionLocal.begin() as session:
        item = seed(db, action_key='logicapp_deploy_prod', status='submitted',
                    requester_oid='okta:SOMEONE-ELSE', execution_status='unknown')
        session.add(item)
        session.flush()
        request_id = item.id
    with TestClient(portal.app, base_url='https://approvals.example.internal') as client:
        route = f'/requests/{request_id}/verify'
        running = client.post(route, data={'outcome': 'running',
            'evidence': 'Run ID 123 checked in Azure Portal: in progress', 'csrf': 'x'}, follow_redirects=False)
        assert running.status_code == 303
        with db.SessionLocal() as session:
            row = session.get(db.Approval, request_id)
            assert row.execution_status == 'running'
            assert row.execution_completed_at is None
        finished = client.post(route, data={'outcome': 'succeeded',
            'evidence': 'Run ID 123 in Azure Portal finished successfully', 'csrf': 'x'}, follow_redirects=False)
        assert finished.status_code == 303
        with db.SessionLocal() as session:
            row = session.get(db.Approval, request_id)
            assert row.execution_status == 'succeeded'
            assert row.execution_completed_at is not None
