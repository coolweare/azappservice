"""SAML settings and signed-claim-to-role mapping tests (without external IdP)."""
import base64
import pytest

from app.saml_auth import principal_from_assertion, role_groups, settings, x509_body, request_data


@pytest.fixture
def okta_env(monkeypatch):
    monkeypatch.setenv('OKTA_SAML_SSO_URL', 'https://tenant.okta.com/app/abc/sso/saml')
    monkeypatch.setenv('OKTA_SAML_IDP_ENTITY_ID', 'http://www.okta.com/externalkey')
    monkeypatch.setenv('OKTA_IDP_X509_CERT', base64.b64encode(b'\x30' + b'X'*500).decode())
    monkeypatch.setenv('OKTA_GROUP_REQUESTER', 'Prod-Automation-Requester')
    monkeypatch.setenv('OKTA_GROUP_APPROVER', 'Prod-Automation-Approver')
    monkeypatch.setenv('OKTA_GROUP_ADMIN', 'Prod-Automation-Admin')


def test_saml_config_is_strict_cert_pinned_and_request_bound(okta_env):
    config = settings('https://approvals.example.internal')
    assert config['strict'] is True
    assert config['security']['wantAssertionsSigned'] is True
    assert config['security']['rejectDeprecatedAlgorithm'] is True
    assert config['sp']['assertionConsumerService']['url'] == 'https://approvals.example.internal/auth/acs'
    assert config['sp']['entityId'] == 'https://approvals.example.internal/saml/metadata'
    assert config['idp']['x509cert']


def test_okta_user_identity_is_immutable_and_roles_are_exact(okta_env):
    groups = role_groups()
    user = principal_from_assertion(
        {'oktaUserId': ['00uABCDEF1234567890'], 'groups': ['Prod-Automation-Requester'],
         'displayName': ['Deploy Engineer']}, 'engineer@example.org', groups)
    assert user == {'oid': 'okta:00uABCDEF1234567890', 'name': 'Deploy Engineer', 'roles': ['Requester']}
    with pytest.raises(PermissionError):
        principal_from_assertion({'oktaUserId':['00uABCDEF1234567890'],
                                  'groups':['Prod-Automation-Approver-TEST']}, 'Person', groups)
    with pytest.raises(ValueError):
        principal_from_assertion({'groups':['Prod-Automation-Admin']}, 'Person', groups)
    with pytest.raises(ValueError):
        principal_from_assertion({'oktaUserId':['person@example.org'],
                                  'groups':['Prod-Automation-Admin']}, 'Person', groups)
    with pytest.raises(ValueError):
        principal_from_assertion({'oktaUserId':['00uABCDEF1234567890', '00u1111111111'],
                                  'groups':['Prod-Automation-Admin']}, 'Person', groups)


def test_duplicate_groups_not_allowed(okta_env, monkeypatch):
    monkeypatch.setenv('OKTA_GROUP_APPROVER', 'Prod-Automation-Requester')
    with pytest.raises(RuntimeError):
        role_groups()


def test_certificate_must_be_x509_not_fingerprint():
    with pytest.raises(RuntimeError):
        x509_body('SHA256:abcd')


def test_canonical_origin_not_untrusted_request_headers():
    d = request_data('https://approvals.example.internal', '/auth/acs', {'SAMLResponse': 'abc'})
    assert d['http_host'] == 'approvals.example.internal'
    assert d['https'] == 'on'
    assert d['post_data']['SAMLResponse'] == 'abc'


def test_invalid_sso_url_rejected(okta_env, monkeypatch):
    monkeypatch.setenv('OKTA_SAML_SSO_URL', 'http://tenant.okta.com/app/abc/sso/saml')
    with pytest.raises(ValueError):
        settings('https://approvals.example.internal')
