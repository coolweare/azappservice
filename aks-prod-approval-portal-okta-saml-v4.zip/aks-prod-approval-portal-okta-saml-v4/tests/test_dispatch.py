from types import SimpleNamespace

from app import dispatcher


class FakeResponse:
    status_code = 201
    headers = {}

    def json(self):
        return {"id": 555, "web_url": "https://gitlab.example.internal/team/a/-/pipelines/555"}


class FakeClient:
    def __init__(self):
        self.requests = []

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def post(self, url, **kwargs):
        self.requests.append((url, kwargs))
        return FakeResponse()


def test_dispatch_gitlab_project_access_token_uses_pipeline_api(monkeypatch):
    fake = FakeClient()
    monkeypatch.setattr(dispatcher, "_https_client", lambda: fake)
    monkeypatch.setattr(dispatcher, "build_attestation", lambda approval, action: 'test-signed-approval')
    monkeypatch.setenv("GITLAB_PROJECT_TOKEN", "dummy-secret")
    action = {
        "kind": "gitlab", "base_url": "https://gitlab.example.internal", "project_id": 101,
        "ref": "main", "auth_mode": "pipeline_api", "require_attestation": True, "token_env": "GITLAB_PROJECT_TOKEN",
        "variables": {"PIPELINE_TYPE": "deploy", "PACKAGE_VERSION": "{package_version}"},
    }
    request = SimpleNamespace(package_version="v1.5", change_ticket="CHG-3", id="req-11")
    status, run_id, link = dispatcher.dispatch(action, request)
    assert (status, run_id) == (201, "555")
    url, kwargs = fake.requests[0]
    assert url.endswith("/api/v4/projects/101/pipeline")
    assert kwargs["headers"]["PRIVATE-TOKEN"] == "dummy-secret"
    assert kwargs["json"]["variables"] == [
        {"key": "PIPELINE_TYPE", "value": "deploy"},
        {"key": "PACKAGE_VERSION", "value": "v1.5"},
        {"key": "APPROVAL_ATTESTATION", "value": "test-signed-approval"},
    ]
    assert link.endswith("/555")


def test_dispatch_gitlab_trigger_token_uses_trigger_api(monkeypatch):
    fake = FakeClient()
    monkeypatch.setattr(dispatcher, "_https_client", lambda: fake)
    monkeypatch.setattr(dispatcher, "build_attestation", lambda approval, action: 'test-signed-approval')
    monkeypatch.setenv("TRIGGER_TOKEN", "trigger-secret")
    action = {
        "kind": "gitlab", "base_url": "https://gitlab.example.internal", "project_id": 101,
        "ref": "main", "auth_mode": "trigger_api", "require_attestation": True, "token_env": "TRIGGER_TOKEN",
        "variables": {"DEPLOY_ENV": "prod"},
    }
    req = SimpleNamespace(package_version="v1.0", change_ticket="CHG-2", id="abc")
    dispatcher.dispatch(action, req)
    url, kwargs = fake.requests[0]
    assert url.endswith("/api/v4/projects/101/trigger/pipeline")
    assert kwargs["data"]["token"] == "trigger-secret"
    assert kwargs["data"]["variables[DEPLOY_ENV]"] == "prod"
