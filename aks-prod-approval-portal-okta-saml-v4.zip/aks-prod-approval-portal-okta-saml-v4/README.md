# Production Automation Approval Portal v4 — Security-Hardened Reference

**Status:** Security-hardened source code and deploy templates; **NOT a production certification**. As of 2026-10-19, 28 local tests pass in the available Python environment. A deployment/upgrade using the newly pinned packages, live Okta SAML authentication and management API, GitLab, Logic Apps/APIM, PostgreSQL, Key Vault, Azure Blob WORM, network policies and image admission control **has not been run**. Placeholders deliberately block deployment until you replace and verify them.

## What this application does

Users sign in via **Okta SAML 2.0**, request an approved, Git-managed production automation, and an independent Okta Approver/Admin may approve or reject it. Approved requests may trigger a self-hosted **GitLab pipeline** or an **Azure API Management (APIM)** fronted **Logic App**. The dashboard displays approvals and GitLab execution results, and authorized operators may manually verify Logic App results with audit evidence.

The v4 controls prevent a privileged GitLab job or APIM workflow from treating user-supplied `APPROVAL_REQUEST_ID` as proof of authorization. Each deployment now requires a **three-minute RS256 signed approval JWT**, independently verified by the downstream enforcement point and consumed only once through the portal's server-side gate. The GitLab gate verifies the protected project, branch, application, change ticket and version. APIM verifies the Logic App audience and **rebuilds** its body from signed claims, not an untrusted client request.

**Security architecture:**

```text
 User browser → HTTPS AKS Ingress → Portal web (Okta SAML)
                                ├── PostgreSQL: approvals, append-only audit,
                                │     server-side sessions and consumed nonces
                                ├── Okta User/Groups API: LIVE authorization
                                ├── GitLab Pipeline API → mandatory protected
                                │   gate verifies signed JWT → consumes jti
                                │   → protected production deploy job
                                └── APIM validate-jwt → consumes jti via portal
                                    → reconstruct signed payload → Logic App

 Separate AKS workload identities: web | status-sync | database-migrate | audit-export
 GitLab status-sync reads ONLY its own GitLab token and DB identity.
 Audit-export reads only audit and sends to a locked immutable Azure Blob container.
```

## 1 — Prerequisites

- Private AKS cluster running an enforcing network policy engine, CSI Secrets Store Azure provider, Workload Identity/OIDC, private DNS and approved internal ingress.
- Okta custom SAML 2.0 app: ACS `https://approvals.example.internal/auth/acs`, SP audience `https://approvals.example.internal/saml/metadata`, signed assertions, `oktaUserId` and `groups` attributes, sign-on policy enforcing MFA/phishing-resistant methods. **SP initiated only.** SAML signing certificate must be stored in Key Vault.
- Okta OAuth service application with private-key JWT authentication authorized only for `okta.users.read` and `okta.groups.read`; its private key stored in web Key Vault and JWK `kid` supplied as `OKTA_API_SIGNING_KID`. It is used to fetch **live** user status and group membership for *each state-changing operation*; Okta outage fails closed. If Okta's API is externally hosted, route HTTPS requests through approved network egress/enterprise proxy.
- Okta Event Hook (optional but highly recommended): authorization header `Bearer <OKTA_EVENT_HOOK_TOKEN>`; target `/api/okta/events`, event types `user.lifecycle.deactivate`, `user.lifecycle.suspend`, `application.user_membership.remove`, `group.user_membership.remove`. For private AKS, publish only this hook path via an appropriately protected APIM/ingress proxy accessible by Okta; do not expose the full portal. Hook delivery is asynchronous. Sensitive actions still use live Okta API revalidation.
- Azure Database for PostgreSQL Flexible Server, private endpoint/DNS, server CA trust, four unique DB roles and separate credentials (web, sync, migration, audit exporter). `sslmode=verify-full` is enforced, even if the URL attempts a weaker mode. **Do not use the migration role in the web workload.**
- Four separate user-assigned managed identities and separate, least-privilege Key Vault scopes (or separate vaults), configured with the four ServiceAccounts and CSI SecretProviderClasses. Ensure each can only read the secrets listed in its own CSI class.
- RSA private key (minimum RSA-2048, preferably RSA-3072) for the portal approval signer in **web-only** Key Vault, and public PEM distributed to a protected GitLab gate and APIM. Use a key ID (`APPROVAL_SIGNING_KID`) and a documented rotation procedure. Never check private keys or gate tokens into the repository.
- Protected GitLab deployment project/branch/environment, protected CI config, protected runner and protected secrets. Gate must execute before any production secrets are made available. Require GitLab environment approvals if licensed; do not permit self-approval.
- APIM inbound `validate-jwt` policy, internal approved callback to protected Logic App, and closed direct SAS URL access. Full signing flow details below. Provision WORM/immutability storage account/container and **lock** its time-based retention policy with your compliance owner.

## 2 — New v4 application security design

| Finding from v3 review | v4 source/config change | Production responsibility |
|---|---|---|
| Outdated dependencies | `requirements.txt`: FastAPI `0.149.0`, Starlette `1.9.0`, lxml `6.1.1`, PyJWT `2.15.1`; `pip-audit` stage | Resolve and scan *complete* pinned dependency graph with an accessible package index; no online scan run here |
| Shared secrets | Four service accounts, four CSI Key Vault configurations, separate database roles, separate GitLab trigger/status and per-destination gate tokens | Create managed identities, Key Vault RBAC and database credentials |
| Network segmentation | Default-deny ingress/egress + DNS, proxy, PostgreSQL, GitLab, APIM, blob and identity egress allow rules; controller-only inbound | Replace TEST-NET CIDRs/namespace labels; verify routing, managed Cilium policy behavior, Azure Firewall and private DNS |
| Downstream bypass | Signed, short-lived approval JWT; GitLab protected gate checks action/project/ref/version; APIM verifies and rebuilds the Logic App payload; one-use DB nonce | Add mandatory gate to deployment project; attach APIM policy, restrict direct Logic App backend |
| Revocation/cached roles | Opaque server-side revocable sessions (10m absolute, 5m idle); Okta lifecycle hook; live Okta user/group revalidation before every mutation | Configure Okta service app and hooks; set MFA/sign-on policies |
| Missing rate limits | Shared DB atomic rate limiting + ingress annotations | Tune thresholds to NAT/proxy traffic and layer-7 proxy IP forwarding policies |
| Database TLS not enforced | SQLAlchemy/psycopg sets `sslmode=verify-full` with trusted CA; rejects downgrade | Set private PostgreSQL FQDN, CA chain, required TLS and firewall |
| Mutable audit history | PostgreSQL append-only trigger and non-edit DB grants; idempotent Azure Blob audit exporter | Enable PRIVATE storage and **LOCKED immutable retention**; monitor exporter backlog and alerts |
| Image supply chain | Digest placeholders for base and app images; CI SAST, secret, dependency and image vulnerability scans, CycloneDX SBOM, Cosign sign/verify, example Kyverno admission | Approve private runner images, wire registry auth/signing keys, deploy and test admission policy |

## 3 — Upgrade v3 → v4

1. Read `UPGRADE_v4.md` **before** changing your cluster; take a verified, restorable PostgreSQL backup, freeze production deployment approvals and snapshot current access policies.
2. Set up Okta management OAuth API service app and optional Event Hook. Build separate managed identities, Key Vault secrets/permissions, PostgreSQL login roles, audit account and immutable container.
3. Apply PostgreSQL additive migration `migrations/003_v4_hardening.sql` with DDL administrator *before* rolling out the new code. Then apply `scripts/migrations/004_app_roles.sql` with precreated roles. Old v3 audit/approval records are preserved; v3-in-flight approvals intentionally become invalid when action fingerprint changes.
4. Implement downstream GitLab and APIM gates and verify they **reject unsigned, expired, tampered, replayed, cross-project and cross-version requests**. Block all bypass paths. The app must not be promoted until both upstream and downstream are ready.
5. Replace all `REPLACE_...` values in manifests, action URLs, signed image digests and network policy CIDRs. Deploy updated web, status sync and audit exporter service accounts and workloads only after infrastructure is ready.
6. Test login, permissions, revocation, approval separation, failure injection, signed gates, immutable audit export, monitoring, rollback and Azure Gov cloud settings if applicable.

## 4 — PostgreSQL migration

Migration scripts are **not executed automatically by a rolling pod deployment**. Use your controlled migration process on an administrator workstation or an explicitly privileged migration Job. **For a brand-new installation, first run `python -m app.manage` using the migration identity to create the complete current schema, then apply migration 003 and GRANT script; do not run legacy 001/002 ALTER scripts before the base approval tables exist.** For an existing v3 database the schema already exists, so apply only 003 and grants. `create_all` does not create the append-only audit trigger or DB GRANTs; you **must** run the SQL scripts.

```bash
# Existing v3 database: using a separately scoped migration identity.
# New install: create base schema first with python -m app.manage, then run 003.
psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/003_v4_hardening.sql
# First create DB login roles independently and provision credentials in Key Vault
psql "$MIGRATION_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -v web_role=portal_web -v sync_role=portal_sync \
  -v export_role=portal_export -v migrate_role=portal_migrate \
  -f scripts/migrations/004_app_roles.sql
```

For an **existing v3 schema**, run only `003_v4_hardening.sql` plus DB grants (do not rerun unrelated bootstrap scripts without review). A revoked session and a consumed approval `jti` are recorded server side in PostgreSQL. `approval_audit` UPDATE/DELETE trigger rejects changes for routine roles; superusers/schema owners are privileged and can still override it, which is why WORM export is essential.

## 5 — Configure GitLab enforcement

1. Put `scripts/verify_approval.py` in a **separate, access-controlled deployment configuration project**, or vendor it only into a protected deployment repository. See `examples/security/gitlab-prod-gate.yml`.
2. Point `APPROVAL_PUBLIC_KEY_PATH` at the verified RSA **public** PEM. Configure `APPROVED_ACTION_KEY`, `APPROVAL_GATE_URL` (trusted HTTPS portal), `GATE_GITLAB_TOKEN` (protected, masked), and the other CI variables under a protected production environment. Configure private networking/CA trust to the portal.
3. In the production deploy job, require `needs: [approval_gate]`, `environment: production`, protected branch and a protected runner. The gate checks the token signature and audience, its three-minute expiry, requester != approver, production environment, package/version/change/approval ID, project ID, ref and `APPROVED_ACTION_KEY`. It then **atomically consumes the attestation**, refusing repeats.
4. Move production connection strings/secrets and deploy scripts to the protected deployment job/project, **not the release or developer-controlled source pipeline**. Use protected environments/approvals when available. Lock protected CI templates against edits by developers who can trigger ordinary pipelines.

**Do not rely on pipeline variables, an approval ID, or the portal's success page alone to authorize a production deployment.**

## 6 — Configure Logic App enforcement

1. Place Logic App behind APIM with private backend access. Configure API operation to use `examples/security/apim-logicapp-jwt-policy.xml` as a reviewed starting policy; set the true production public RSA modulus/exponent using `scripts/public_key_modulus.py`; create Key Vault-backed APIM named value `approval-logicapp-gate-token` (separate from GitLab's).
2. Ensure APIM can reach the portal's private `/api/attestations/consume` endpoint over HTTPS and only APIM has access to the Logic App's actual callback secret/back end. Reject bypass requests that go directly to the Logic App. Configure the operation to forward to the real Logic App backend (not shown in the example policy).
3. Set `LOGIC_APP_CALLBACK_URL` to **APIM HTTPS operation URL with no SAS query**, and `gateway_host` in `actions.yaml` to its exact host. Portal rejects direct `*.logic.azure.com?...sig=...` callback URLs. APIM validates the signed JWT and requires approved action, audience, `environment=prod`, and consumes `jti` with the target-specific gate secret. APIM **reconstructs the Logic App input** from signed claims so an attacker cannot alter `packageVersion` in an HTTP POST body.
4. Run tests for forged data, expired/replayed tokens, APIM backend protection, Azure Logic App HTTP 202 and timeouts. The portal still reports an upstream acceptance as **not necessarily success**, with manual verification when needed.

## 7 — Kubernetes and Key Vault deployment

```bash
# Replace EVERY placeholder first; these manifests are intentionally NOT ready to apply.
kubectl apply -f deploy/00-namespace.yaml
kubectl apply -f deploy/01-service-account.yaml
kubectl apply -f deploy/02-secretproviderclass.yaml
kubectl apply -f deploy/03-settings.yaml
kubectl -n prod-automation create configmap approval-actions --from-file=actions.yaml \
  --dry-run=client -o yaml | kubectl apply -f -
# After schema migration, downstream policy deployment and signed-image verification:
kubectl apply -f deploy/04-deployment.yaml
kubectl apply -f deploy/05-service.yaml
kubectl apply -f deploy/06-ingress.yaml
kubectl apply -f deploy/09-gitlab-status-cronjob.yaml
kubectl apply -f deploy/10-audit-export-cronjob.yaml
# Apply deploy/08-network-policy.example.yaml ONLY after real destination CIDRs,
# namespace labels and an enforcing policy engine are confirmed.
```

**Note:** `deploy/07-migrate-job.yaml` is a first-install bootstrap helper only and should not be used as a production migration strategy after v3. Rollback to v3 after migrating v4 is **not** a safe application rollback by simply redeploying a v3 image; use the vetted database and deployment rollback plan in `UPGRADE_v4.md`.

## 8 — CI and image admission

The included `.gitlab-ci.yml` describes a strict order: tests/static scans → build → image CVE scan/SBOM → Cosign sign & verify. `deploy/admission/kyverno-verify-images.example.yaml` is a sample cluster admission policy (requires separately managed Kyverno; Azure Policy/Ratify can be substituted). In all images and CI job images, `sha256:REPLACE_...` **must** be replaced by reviewed immutable digests. CI is intentionally not runnable while placeholders remain. A successful local pytest run is not proof that the CI scans pass in your registry.

Review both Python and Debian OS-package CVEs; enable SBOM, secret detection, SAST, image scanning and artifact signing on each change, and keep a lockfile with transitive hashes from your enterprise artifact mirror. Do not use host-mounted Docker sockets or unprotected privileged runners for production.

### Emergency Okta session revocation

Run with separately authorized operational access and read-only exposure to audit output: `python -m app.revoke --okta-user-id 00u...` (requires a DB connection with UPDATE permission on `login_sessions`). This immediately invalidates any outstanding portal sessions for that Okta user. Routine production writes additionally revalidate live Okta user status/group membership.

## 9 — Observability and risk boundaries

Log events to your approved Splunk/Dynatrace and/or Azure monitoring stack. Alert on failed SAML assertions, 429 rates, denied/replayed downstream attestation, missing audit exports, stuck dispatches, unknown run statuses, failed critical image scans and abnormal Key Vault access. Monitor WORM audit-export cursor lag and separately test retention policy irreversibility. The issuer's private signing key, protected GitLab runners, Okta service app, K8s control plane and database credentials remain privileged trust anchors and must be monitored/rotated.

**Limitations:** This is an implementation baseline, not an externally validated security assessment. Okta Event Hook delivery is asynchronous (sensitive writes perform *live* revalidation). APIM Policy XML and sample Kyverno enforcement still require real tenant and runtime validation. GitLab protected environment/pipeline template rules, private network policy destinations, WORM account retention lock, image-signing key setup and production scans are **not** automatically established by including YAML in this repository. See `SECURITY_CHANGES.md`.
