# Security remediation record — v4 (2026-10-19)

This repo implements mitigations for the v3 audit, but cannot attest to controls that are configured in customer infrastructure. All compliance claims are conditional on deployment and independent review. Static templates with `REPLACE_...` prevent premature deployment.

| V3 issue | Source code implemented | Remaining external validation/configuration |
|---|---|---|
| lxml/Starlette CVEs | Pins lxml 6.1.1 (fix >=6.1.0) and Starlette 1.9.0 (fix >=1.0.1), FastAPI 0.149.0. | Build new venv/container, check resolver, scan *all* dependencies/OS layers. |
| Shared identities/secrets | Four different Kubernetes SAs, CSI SPCs, DB URL secrets; monitor uses read-only GitLab token; separate downstream gate tokens. | Create and verify correct IAM/RBAC/Key Vault scopes and DB roles. |
| Missing egress restrictions | Default-deny network policy; explicit private SQL/GitLab/APIM/Okta proxy/Blob/STS CIDR-only allow. | Replace reserved `192.0.2.x/32` placeholders with real destinations and monitor enforcement. |
| Downstream bypass | RS256 short-lived signed JWT with action hash, version, ticket, requester, approver, audience, project/ref; consumed once under DB transaction; mandatory GitLab/Logic App gate templates. | Protect GitLab deployment project and enforce gate on every production job; APIM operation + backend private restrictions; verify not bypassable. |
| Stale Okta roles | Server-side revocable opaque sessions (10 min maximum, 5 min idle); Okta event hook revokes users; **live user ACTIVE/group check before production mutations, fail closed**. | Configure OAuth service app private-key JWT and permissions, external egress, MFA, event hook delivery verification. |
| No rate limiting | DB atomic request buckets per source + NGINX ingress limits. | Tune and test for shared NAT/proxy address traffic; configure genuine client IP handling in ingress. |
| Database not TLS verified | psycopg connection forces `verify-full` and trusted CA file. | Valid FQDN, trusted CA and private endpoint; Azure Commercial/Gov trust tests. |
| Mutable audits | DB trigger prevents audit UPDATE/DELETE; role grants exclude audit UPDATE/DELETE; cursor-based idempotent exporter to Blob. | Set up and LOCK Azure Blob immutability policies; prove export and deletion denial. |
| Supply-chain hardening missing | CI static tests, pip-audit/Bandit/detect-secrets, Trivy, SBOM, Cosign signing, digest-pinned image placeholders, Kyverno policy template. | Internal signed job images, verified digests, image build/scans and admission installed/enforced. |

**Local verification:** `pytest -q` = 28 passing tests with the packages installed in this environment (not the full new pinned v4 environment). XML/YAML parsed; `python scripts/check_security_settings.py` passed. Docker engine, internet-connected dependency vulnerability scan, cloud accounts, live IdP/API gateway, and AKS cluster are not available in this execution context. No live security controls are claimed to be operational.

**Important trust boundaries:** Same-cluster compromise of the portal signer plus DB user can still be a severe incident. Protect its identity and runtime, limit approver privileges, observe immutable external audits, rotate signing keys and gate credentials regularly. Upstream trigger accepting a request is not deployment success, and after a gate consumes a nonce a failed backend can require a *new* approval, never a re-used JWT.
