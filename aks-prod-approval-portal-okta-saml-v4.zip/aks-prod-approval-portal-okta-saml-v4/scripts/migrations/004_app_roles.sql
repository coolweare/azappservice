-- psql -v ON_ERROR_STOP=1 -v web_role=portal_web -v sync_role=portal_sync \
--   -v migrate_role=portal_migrate -v export_role=portal_export -f scripts/migrations/004_app_roles.sql
-- SECURITY: Precreate four LOGIN roles and provision separate passwords/identities
-- via Key Vault. Do not execute CREATE ROLE with plaintext credentials in CI logs.
\set ON_ERROR_STOP on
BEGIN;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO :"web_role", :"sync_role", :"export_role";
GRANT SELECT, INSERT, UPDATE ON approval_requests, saml_login_requests, login_sessions, rate_buckets, attestation_uses TO :"web_role";
GRANT DELETE ON saml_login_requests TO :"web_role";
GRANT SELECT, INSERT ON approval_audit TO :"web_role";
GRANT SELECT, UPDATE ON approval_requests TO :"sync_role";
GRANT INSERT ON approval_audit TO :"sync_role";
GRANT SELECT ON approval_audit TO :"export_role";
GRANT SELECT, INSERT, UPDATE ON audit_export_cursors TO :"export_role";
COMMIT;
