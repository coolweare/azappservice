"""Fail closed on detect-secrets findings in CI (no sample credentials)."""
import json
import sys
with open(sys.argv[1], encoding='utf-8') as f:
    data = json.load(f)
count = sum(len(v) for v in data.get('results', {}).values())
print('Secret scan findings:', count)
sys.exit(1 if count else 0)
