"""Static manifest and allowlist assertions enforced in protected GitLab CI."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.config import load_actions

actions = load_actions('actions.yaml')
assert all(a['require_attestation'] is True for a in actions.values())
root = Path('deploy')
text = (root / '04-deployment.yaml').read_text()
for flag in ['runAsNonRoot: true', 'readOnlyRootFilesystem: true', 'allowPrivilegeEscalation: false',
             'seccompProfile:', 'drop: [ALL]', '@sha256:']:
    assert flag in text, flag
for name in ('web', 'sync', 'migration', 'audit-export'):
    assert name in (root / '02-secretproviderclass.yaml').read_text()
assert 'deny-all-prod-automation' in (root / '08-network-policy.example.yaml').read_text()
assert 'validate-jwt' in Path('examples/security/apim-logicapp-jwt-policy.xml').read_text()
print('Security configuration preflight passed')
