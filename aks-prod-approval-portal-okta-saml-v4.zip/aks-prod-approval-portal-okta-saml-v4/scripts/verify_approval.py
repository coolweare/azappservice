#!/usr/bin/env python3
"""Run as a mandatory .pre job in the PROTECTED deployment pipeline.

Requires pyjwt[crypto]. Exit nonzero on missing/mismatched/expired evidence.
Do NOT print the token to logs; use GitLab masked variable.
"""
import os
import sys
from pathlib import Path

import jwt


def verify(environ):
    token = environ['APPROVAL_ATTESTATION']
    # Trusted deployment gate public key distributed by a protected config repo
    key_path = environ['APPROVAL_PUBLIC_KEY_PATH']
    key = Path(key_path).read_text()
    if jwt.get_unverified_header(token).get('alg') != 'RS256':
        raise ValueError('Unsafe signature algorithm')
    claims = jwt.decode(token, key, algorithms=['RS256'],
                        audience='prod-automation:gitlab', issuer='aks-prod-approval-portal',
                        options={'require': ['exp', 'iat', 'nbf', 'jti', 'request_id',
                          'action_key', 'action_hash', 'package_version', 'change_ticket',
                          'requester', 'approver', 'kind', 'environment', 'project_id', 'ref']}, leeway=10)
    if claims['kind'] != 'gitlab' or claims['environment'] != 'prod':
        raise ValueError('Not a production GitLab attestation')
    if claims['requester'].lower() == claims['approver'].lower():
        raise ValueError('Self approval')
    for name, claim in (('PACKAGE_VERSION', 'package_version'),
                        ('CHANGE_TICKET', 'change_ticket'),
                        ('APPROVAL_REQUEST_ID', 'request_id')):
        if not environ.get(name) or environ[name] != claims[claim]:
            raise ValueError(f'{name} does not match approved change')
    if environ.get('DEPLOY_ENV') != 'prod':
        raise ValueError('Environment must be prod')
    if environ.get('PIPELINE_TYPE') != 'deploy':
        raise ValueError('Wrong pipeline type')
    if environ.get('CI_PROJECT_ID') != claims['project_id'] or environ.get('CI_COMMIT_REF_NAME') != claims['ref']:
        raise ValueError('Wrong protected project/ref')
    if environ.get('CI_COMMIT_REF_PROTECTED') != 'true':
        raise ValueError('Unprotected Git ref')
    if environ.get('APPROVED_ACTION_KEY') != claims['action_key']:
        raise ValueError('Wrong action')
    # Atomic use-once check with the trusted portal, so leaked JWTs cannot be
    # replayed within their short validity window. Non-200 means DENY.
    import httpx
    endpoint = environ['APPROVAL_GATE_URL'].rstrip('/') + '/api/attestations/consume'
    from urllib.parse import urlparse
    parsed = urlparse(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Gate endpoint must use HTTPS')
    with httpx.Client(timeout=10, follow_redirects=False, trust_env=False,
                      verify=environ.get('APPROVAL_GATE_CA_BUNDLE') or True) as client:
        response = client.post(endpoint, headers={'x-approval-gate-token': environ['GATE_GITLAB_TOKEN']},
                               json={'attestation': token})
        response.raise_for_status()
        if response.json().get('approval_id') != claims['request_id']:
            raise ValueError('Downstream approval ID mismatch')
    return claims


if __name__ == '__main__':
    try:
        claims = verify(os.environ)
    except (Exception, KeyError) as exc:
        print('PRODUCTION APPROVAL GATE: DENIED (' + type(exc).__name__ + ')', file=sys.stderr)
        sys.exit(1)
    print('PRODUCTION APPROVAL GATE: VERIFIED for request ' + claims['request_id'])
