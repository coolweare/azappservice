#!/usr/bin/env bash
# Review only: writes NO Azure resources. Replace placeholders, vet tenant/cloud.
set -euo pipefail
cat <<'COMMANDS'
# FIRST: Create a dedicated storage account with private endpoint and public
# network access disabled. Use AZURE_CLOUD_NAME (AzureCloud/AzureUSGovernment).
# NEXT: create dedicated container with version-level immutability support.
# THEN: configure a time-based retention policy and inspect Azure control-plane
# settings/retention/legal hold with governance. Lock only after approval; a
# LOCKED immutable policy cannot be shortened or deleted before expiry.
# For exact command syntax for your az version consult:
# https://learn.microsoft.com/azure/storage/blobs/immutable-policy-configure-version-scope
# https://learn.microsoft.com/cli/azure/storage/container/immutability-policy
# Always use az cloud set and az login on approved secure infrastructure.
COMMANDS
