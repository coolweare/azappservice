"""Generate APIM RSA public modulus from PEM (public keys are not secrets)."""
import base64
import sys
from cryptography.hazmat.primitives.serialization import load_pem_public_key


def b64url(number):
    return base64.urlsafe_b64encode(number.to_bytes((number.bit_length() + 7)//8, 'big')).decode().rstrip('=')

numbers = load_pem_public_key(open(sys.argv[1], 'rb').read()).public_numbers()
print('n=' + b64url(numbers.n))
print('e=' + b64url(numbers.e))
